let toggleTime = 1000;
let state = 0;
let allowUpdate = true;

loadingIcon.addEventListener('click', function() {
    allowUpdate = false;
    setTimeout(() => {
      allowUpdate = true;
    }, 2500);

    if (monitor) {
        state = (state + 1) % 3; // 0 → 1 → 2 → 0…
    } else {
        state = state === 0 ? 1 : 0;
    }

    if (state === 1) {
        // hide world clock & weather
        toggleTextVisibility(".city-name1", ".world-clock1");
        setTimeout(() => toggleTextVisibility(".city-name2", ".world-clock2"), 150);
        setTimeout(() => toggleTextVisibility(".temp", ".forecast"), 300);
        setTimeout(function() {tinyLine.style.opacity = '0';}, toggleTime * 0.33);
        setTimeout(function() {tinyLine2.style.opacity = '0';}, toggleTime * 0.66);
        setTimeout(function() {tinyLine5.style.opacity = '0';}, toggleTime * 1);
        setTimeout(function() {$(audioBars).animate({ 'height': '7vh' }, toggleTime, 'easeInOutQuart');}, toggleTime * 1.75);

        // show media info
        toggleTextVisibility(".duration", ".album-name");
        setTimeout(() => {
            tinyLine3.style.display = 'block';
            tinyLine4.style.display = 'block';
        }, 2000);
        setTimeout(function() {
            $(virticalLine).animate({ height: '10.5vh' }, toggleTime, 'easeInOutQuart');
            $(duration).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumName).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumCover).show().animate({ 'margin-top': '0vh' }, toggleTime, 'easeInOutQuart');
        }, toggleTime);
    } else if (state === 2 && monitor) {
        // hide media info
        toggleTextVisibility(".duration", ".album-name");
        tinyLine3.style.display = 'none';
        tinyLine4.style.display = 'none';
        $(virticalLine).animate({ height: '0vh' }, toggleTime, 'easeInOutQuart');
        $(duration).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(albumName).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(albumCover).animate({ 'margin-top': '-9.5vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(audioBars).animate({ 'height': '0vh' }, 250, 'easeInOutQuart');

        // show performance monitor
        toggleTextVisibility(".performance-1-name", ".performance-2-name", ".performance-3-name", ".performance-4-name");
        setTimeout(() => {
            document.querySelectorAll(".performance-line").forEach(el => el.style.opacity = '1');
            document.querySelectorAll(".line-shadow-2").forEach(el => el.style.width = '100%');
            document.querySelector("#tiny-line-6").style.opacity = '1';
            document.querySelector("#tiny-line-7").style.opacity = '1';
        }, 1500);
    } else {
        // hide performance monitor
        document.querySelectorAll(".performance-line").forEach(el => el.style.opacity = '0');
        document.querySelectorAll(".line-shadow-2").forEach(el => el.style.width = '0%');
        document.querySelector("#tiny-line-6").style.opacity = '0';
        document.querySelector("#tiny-line-7").style.opacity = '0';
        setTimeout(() => toggleTextVisibility(".performance-1-name", ".performance-2-name", ".performance-3-name", ".performance-4-name"), 300);

        // show world clock & weather
        setTimeout(() => toggleTextVisibility(".city-name1", ".world-clock1"), 300);
        setTimeout(() => toggleTextVisibility(".city-name2", ".world-clock2"), 450);
        setTimeout(() => toggleTextVisibility(".temp", ".forecast"), 600);
        setTimeout(function() {
            setTimeout(function() {tinyLine.style.opacity = '1';}, toggleTime * 0.33);
            setTimeout(function() {tinyLine2.style.opacity = '1';}, toggleTime * 0.66);
            setTimeout(function() {tinyLine5.style.opacity = '1';}, toggleTime * 1);
        }, 1000);
    

    }

    loadingIcon.style.pointerEvents = 'none';
    setTimeout(function() {
        loadingIcon.style.pointerEvents = '';
    }, 2500);
});


function toggleTextVisibility(...elements) {
    elements.forEach(elementId => {
        const textElement = document.querySelector(elementId);
        if (!textElement) return;

        // 元のテキストを保存しておく
        if (!textElement.dataset.originalText) {
            textElement.dataset.originalText = textElement.textContent;
        }

        const originalText = textElement.dataset.originalText;
        const chars = originalText.split('');
        let index = 0;

        const isVisible = textElement.offsetParent !== null && textElement.style.display !== 'none';

        function updateText(action) {
            if (action === 'hide') {
                if (index < chars.length) {
                    chars[index] = `<span class="hiddenChars">${chars[index]}</span>`;
                    textElement.innerHTML = chars.join('');
                    index++;
                    setTimeout(() => updateText('hide'), (toggleTime * 0.75) / chars.length);
                } else {
                    textElement.style.display = 'none';
                }
            } else if (action === 'show') {
                if (index === 0) {
                    textElement.style.display = 'block';
                }
                if (index < chars.length) {
                    const visibleText = chars.slice(0, index + 1).join('');
                    textElement.innerHTML = visibleText;
                    index++;
                    setTimeout(() => updateText('show'), (toggleTime * 0.75) / chars.length);
                }
            }
        }

        if (isVisible) {
            updateText('hide');
        } else {
            setTimeout(() => updateText('show'), 1000);
        }
    });
}


