// 初期状態をlocalStorageから読み込む。存在しない場合はデフォルト値を使用
let isInfoVisible = localStorage.getItem('isInfoVisible') !== null ? 
                    JSON.parse(localStorage.getItem('isInfoVisible')) : true;
let isTextVisible = !isInfoVisible;
let toggleTime = 1000;

// ページ読み込み時に保存された状態を復元
document.addEventListener('DOMContentLoaded', function() {
    restoreVisibilityState();
});

function saveVisibilityState() {
    localStorage.setItem('isInfoVisible', JSON.stringify(isInfoVisible));
}

function restoreVisibilityState() {
    if (!isInfoVisible) {
        // 非表示状態だった場合、即座に要素を非表示にする
        document.querySelectorAll(".city-name1, .world-clock1, .city-name2, .world-clock2, .temp, .forecast").forEach(el => {
            el.style.display = 'none';
        });
        document.querySelectorAll(".duration, .album-name").forEach(el => {
            el.style.display = 'block';
        });
        
        tinyLine.style.opacity = '0';
        tinyLine2.style.opacity = '0';
        tinyLine3.style.display = 'block';
        tinyLine4.style.display = 'block';
        tinyLine5.style.opacity = '0';
        virticalLine.style.height = '10.5vh';
        duration.style.top = '8vh';
        albumName.style.top = '8vh';
        albumCover.style.marginTop = '0vh';
        audioBars.style.height = '7vh';
    }
}

loadingIcon.addEventListener('click', function() {
    isTextVisible = !isTextVisible;
    toggleTextVisibility(".city-name1", ".world-clock1");
    setTimeout(() => toggleTextVisibility(".city-name2", ".world-clock2"), 150);
    setTimeout(() => toggleTextVisibility(".temp", ".forecast"), 300);
    toggleTextVisibility2(".duration", ".album-name");

    if (isInfoVisible) {
        setTimeout(function() {tinyLine.style.opacity = '0';}, toggleTime * 0.5);
        setTimeout(function() {tinyLine2.style.opacity = '0';}, toggleTime * 0.75);
        setTimeout(function() {tinyLine5.style.opacity = '0';}, toggleTime * 1);
        setTimeout(function() {$(audioBars).animate({ 'height': '7vh' }, toggleTime, 'easeInOutQuart');}, toggleTime * 1.75);

        setTimeout(() => {
            tinyLine3.style.display = 'block';
            tinyLine4.style.display = 'block';
        }, 2000);

        setTimeout(function() {
            $(virticalLine).animate({ height: '10.5vh' }, toggleTime, 'easeInOutQuart');
            $(duration).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumName).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumCover).show().animate({ 'margin-top': '0vh' }, toggleTime, 'easeInOutQuart');
        }, toggleTime);

    } else {
        setTimeout(function() {
            setTimeout(function() {tinyLine.style.opacity = '1';}, toggleTime * 0.5);
            setTimeout(function() {tinyLine2.style.opacity = '1';}, toggleTime * 0.75);
            setTimeout(function() {tinyLine5.style.opacity = '1';}, toggleTime * 1);
        }, 500);
        
        tinyLine3.style.display = 'none';
        tinyLine4.style.display = 'none';
        $(virticalLine).animate({ height: '0vh' }, toggleTime, 'easeInOutQuart');
        $(duration).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(albumName).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(albumCover).animate({ 'margin-top': '-9.5vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(audioBars).animate({ 'height': '0vh' }, 250, 'easeInOutQuart');
    }

    isInfoVisible = !isInfoVisible;
    saveVisibilityState(); // 状態を保存

    loadingIcon.style.pointerEvents = 'none';
    setTimeout(function() {
        loadingIcon.style.pointerEvents = '';
    }, 2500);
});


function toggleTextVisibility(...elements) {
    elements.forEach(elementId => {
        const textToHide = document.querySelector(elementId);
        const chars = textToHide.textContent.split('');
        
        const action = !isTextVisible ? 'show' : 'hide';
        let index = 0;

        function updateText(action) {
            if (action === 'hide') {
                if (index < chars.length) {
                    chars[index] = `<span class="hiddenChars">${chars[index]}</span>`;
                    textToHide.innerHTML = chars.join('');
                    index++;
                    setTimeout(() => updateText('hide'), toggleTime / chars.length);
                } else {
                    textToHide.style.display = 'none';
                }
            } else if (action === 'show') {
                if (index < chars.length) {
                    textToHide.style.display = 'block';
                    const slicedText = chars.slice(0, index + 1).join('');
                    textToHide.innerHTML = slicedText;
                    index++;
                    setTimeout(() => updateText('show'), toggleTime / chars.length);
                }
            }
        }

        if (action === 'show') {
            setTimeout(() => updateText('show'), 1000);
        } else {
            updateText('hide');
        }
    });
}

function toggleTextVisibility2(...elements) {
    elements.forEach(elementId => {
        const textToHide = document.querySelector(elementId);
        const chars = textToHide.textContent.split('');
        
        const action = !isTextVisible ? 'hide' : 'show';
        let index = 0;

        function updateText(action) {
            if (action === 'hide') {
                if (index < chars.length) {
                    chars[index] = `<span class="hiddenChars">${chars[index]}</span>`;
                    textToHide.innerHTML = chars.join('');
                    index++;
                    setTimeout(() => updateText('hide'), toggleTime / chars.length / 2);
                } else {
                    textToHide.style.display = 'none';
                }
            } else if (action === 'show') {
                if (index < chars.length) {
                    textToHide.style.display = 'block';
                    var slicedText = chars.slice(0, index + 1).join('');
                    textToHide.innerHTML = slicedText;
                    index++;
                    setTimeout(() => updateText('show'), toggleTime / chars.length);
                }
            }
        }

        if (action === 'show') {
            setTimeout(() => updateText('show'), 1000);
        } else {
            updateText('hide');
        }
    });
}
