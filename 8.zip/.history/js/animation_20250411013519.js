let isInfoVisible = localStorage.getItem('isInfoVisible') === 'true' || true;
let isTextVisible = localStorage.getItem('isTextVisible') === 'true' || false;
let toggleTime = 1000;

loadingIcon.addEventListener('click', function() {
    // Toggle isTextVisible and store the state
    isTextVisible = !isTextVisible;
    localStorage.setItem('isTextVisible', isTextVisible);

    // Toggle visibility for cityname and worldclock elements
    toggleTextVisibility(".city-name1", ".world-clock1");
    setTimeout(() => toggleTextVisibility(".city-name2", ".world-clock2"), 300);
    toggleTextVisibility2(".duration", ".album-name");

    // Handle the info visibility toggle
    if (isTextVisible) {
        // Hide other elements when cityname/worldclock is visible
        hideOtherElements();

        setTimeout(function() { tinyLine.style.opacity = '0'; }, toggleTime * 0.5);
        setTimeout(function() { tinyLine2.style.opacity = '0'; }, toggleTime * 0.75);
        setTimeout(function() { $(audioBars).animate({ 'height': '7vh' }, toggleTime, 'easeInOutQuart'); }, toggleTime * 1.75);

        setTimeout(() => {
            tinyLine3.style.display = 'block';
            tinyLine4.style.display = 'block';
        }, 2000);

        setTimeout(function() {
            $(virticalLine).animate({ height: '10.5vh' }, toggleTime, 'easeInOutQuart');
            $(duration).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumName).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumCover).show().animate({ 'margin-top': '0vh' }, toggleTime, 'easeInOutQuart');
        }, toggleTime);
    } else {
        // Show other elements when cityname/worldclock is not visible
        showOtherElements();

        setTimeout(function() {
            setTimeout(function() { tinyLine.style.opacity = '1'; }, toggleTime * 0.5);
            setTimeout(function() { tinyLine2.style.opacity = '1'; }, toggleTime * 0.75);
        }, 500);

        tinyLine3.style.display = 'none';
        tinyLine4.style.display = 'none';
        $(virticalLine).animate({ height: '0vh' }, toggleTime, 'easeInOutQuart');
        $(duration).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() { $(this).hide(); });
        $(albumName).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() { $(this).hide(); });
        $(albumCover).animate({ 'margin-top': '-9.5vh' }, toggleTime, 'easeInOutQuart', function() { $(this).hide(); });
        $(audioBars).animate({ 'height': '0vh' }, 250, 'easeInOutQuart');
    }

    // Toggle isInfoVisible and store the state
    isInfoVisible = !isInfoVisible;
    localStorage.setItem('isInfoVisible', isInfoVisible);

    loadingIcon.style.pointerEvents = 'none';
    setTimeout(function() {
        loadingIcon.style.pointerEvents = '';
    }, 2500);
});

// Function to hide all elements except cityname and worldclock
function hideOtherElements() {
    const elementsToHide = [
        ".duration", ".album-name", ".album-cover", ".virtical-line", 
        ".audio-bars"
    ];
    elementsToHide.forEach(selector => {
        const element = document.querySelector(selector);
        if (element) {
            element.style.display = 'none';
        }
    });
}

// Function to show all elements except cityname and worldclock
function showOtherElements() {
    const elementsToShow = [
        ".duration", ".album-name", ".album-cover", ".virtical-line", 
        ".audio-bars"
    ];
    elementsToShow.forEach(selector => {
        const element = document.querySelector(selector);
        if (element) {
            element.style.display = 'block';
        }
    });
}

function toggleTextVisibility(...elements) {
    elements.forEach(elementId => {
        const textToHide = document.querySelector(elementId);
        const chars = textToHide.textContent.split('');
        let index = 0;

        function updateText(action) {
            if (action === 'hide') {
                if (index < chars.length) {
                    chars[index] = `<span class="hiddenChars">${chars[index]}</span>`;
                    textToHide.innerHTML = chars.join('');
                    index++;
                    setTimeout(() => updateText('hide'), toggleTime / chars.length);
                } else {
                    textToHide.style.display = 'none';
                }
            } else if (action === 'show') {
                if (index < chars.length) {
                    textToHide.style.display = 'block';
                    const slicedText = chars.slice(0, index + 1).join('');
                    textToHide.innerHTML = slicedText;
                    index++;
                    setTimeout(() => updateText('show'), toggleTime / chars.length);
                }
            }
        }

        const action = isTextVisible ? 'show' : 'hide';
        updateText(action);
    });
}

function toggleTextVisibility2(...elements) {
    elements.forEach(elementId => {
        const textToHide = document.querySelector(elementId);
        const chars = textToHide.textContent.split('');
        let index = 0;

        function updateText(action) {
            if (action === 'hide') {
                if (index < chars.length) {
                    chars[index] = `<span class="hiddenChars">${chars[index]}</span>`;
                    textToHide.innerHTML = chars.join('');
                    index++;
                    setTimeout(() => updateText('hide'), toggleTime / chars.length / 2);
                } else {
                    textToHide.style.display = 'none';
                }
            } else if (action === 'show') {
                if (index < chars.length) {
                    textToHide.style.display = 'block';
                    const slicedText = chars.slice(0, index + 1).join('');
                    textToHide.innerHTML = slicedText;
                    index++;
                    setTimeout(() => updateText('show'), toggleTime / chars.length);
                }
            }
        }

        const action = isTextVisible ? 'show' : 'hide';
        updateText(action);
    });
}
