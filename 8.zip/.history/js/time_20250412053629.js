// current date
const currentDateElement = document.getElementById('currentDate');
const currentDate = new Date().toLocaleDateString('en-US', {
  weekday: 'long',
  year: 'numeric',
  month: 'short',
  day: 'numeric'
}).replace(/(\w+) (\d+), (\d+)/, '$1. $2, $3');
currentDateElement.textContent = currentDate;

// current time
function getCurrentTime() {
    const currentDate = new Date();
    let hours = currentDate.getHours().toString().padStart(2, '0'); // 時を取得し、2桁の0埋めにする
    const minutes = currentDate.getMinutes().toString().padStart(2, '0'); // 分を取得し、2桁の0埋めにする
    const seconds = currentDate.getSeconds().toString().padStart(2, '0'); // 秒を取得し、2桁の0埋めにする

    let dayTimeMark = '';
    if (hours >= 6 && hours < 18) {
        dayTimeMark = '*';
    } else {
        dayTimeMark = '';
    }

    let ampm = '';
    if (!use24clock) {
        if (hours > 12) {
            ampm = ' PM';
            hours -= 12;
        } else if (hours === 0) {
            ampm = ' AM';
            hours = 12;
        } else if (hours === 12) {
            ampm = ' PM';
            hours = 12;
        } else {
            ampm = ' AM';
        }
    }

    const currentTimeElement = document.getElementById('currentTime');

    if (!showSeconds) {
        currentTimeElement.textContent = `${hours}:${minutes}${ampm} ${dayTimeMark}`;
    } else {
        currentTimeElement.textContent = `${hours}:${minutes}:${seconds}${ampm} ${dayTimeMark}`;
    }
}
setInterval(getCurrentTime, 1000);

// day process
function calculateDayProcess() {
    const currentDate = new Date();
    const hours = currentDate.getHours();
    const minutes = currentDate.getMinutes();
    const seconds = currentDate.getSeconds();

    const totalSeconds = (hours * 3600) + (minutes * 60) + seconds;
    const totalSecondsInADay = 24 * 3600;

    const percentage = Math.floor((totalSeconds / totalSecondsInADay) * 100);
    const dayProcessElement = document.getElementById('dayProcess');
    dayProcessElement.textContent = percentage + '%';

    // process line width
    const width = (percentage / 100) * 19.5;
    processLineElement.style.width = width + 'vh';
}
setInterval(calculateDayProcess, 1000);

function worldClockOne() {
    if (!allowUpdate) return;
    const currentDate = new Date();
    let londonTimeObj = new Date().toLocaleString('en-US', { timeZone: TimeZone1 });
    const londonDate = new Date(londonTimeObj);

    const worldClock1Element = document.querySelector('.world-clock1');
    let cityNameElement = document.querySelector('.city-name1');

    let londonTime;
    let hour;

    // 24時間表示かどうかでフォーマットを分ける
    if (use24clock) {
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: showSeconds ? '2-digit' : undefined,
            hour12: false,
            timeZone: TimeZone1,
        };
        londonTime = new Date().toLocaleTimeString('en-GB', options);
        hour = parseInt(londonTime.split(':')[0], 10);
    } else {
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: showSeconds ? '2-digit' : undefined,
            hour12: true,
            timeZone: TimeZone1,
        };
        londonTime = new Date().toLocaleTimeString('en-US', options);
        
        const match = londonTime.match(/^([^:]*):/); // 例: "3:45 PM"
        hour = parseInt(match[1], 10);
        const ampmMatch = londonTime.match(/ (AM|PM)/i);
        const ampm = ampmMatch ? ampmMatch[1].toLowerCase() : '';

        // PMのときはhourを24時間に換算
        if (ampm === 'pm' && hour !== 12) hour += 12;
        if (ampm === 'am' && hour === 12) hour = 0;
    }

    // 昼間マーク（6〜17時）を追加
    let isDaytime = (hour >= 6 && hour < 18) ? ' *' : '';

    // compare only the dates without considering time
    const londonDateWithoutTime = new Date(londonDate.getFullYear(), londonDate.getMonth(), londonDate.getDate());
    const currentDateWithoutTime = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());

    // add day checker and show
    if (londonDateWithoutTime.getTime() < currentDateWithoutTime.getTime()) {
        worldClock1Element.textContent = `${londonTime}${isDaytime} Previous Day`;
    } else if (londonDateWithoutTime.getTime() > currentDateWithoutTime.getTime()) {
        worldClock1Element.textContent = `${londonTime}${isDaytime} Next Day`;
    } else {
        worldClock1Element.textContent = londonTime + isDaytime;
    }

    cityNameElement.textContent = TimeZone1;
}





//world clock 2
function worldClockTwo() {
    if (!allowUpdate) return;
    const currentDate = new Date();
    let londonTimeObj = new Date().toLocaleString('en-US', { timeZone: TimeZone2 });
    const londonDate = new Date(londonTimeObj);

    const worldClock1Element = document.querySelector('.world-clock2');
    const cityNameElement = document.querySelector('.city-name2');

    let londonTime;
    let hour;

    // 24時間表示かどうかでフォーマットを分ける
    if (use24clock) {
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: showSeconds ? '2-digit' : undefined,
            hour12: false,
            timeZone: TimeZone2,
        };
        londonTime = new Date().toLocaleTimeString('en-GB', options);
        hour = parseInt(londonTime.split(':')[0], 10);
    } else {
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: showSeconds ? '2-digit' : undefined,
            hour12: true,
            timeZone: TimeZone2,
        };
        londonTime = new Date().toLocaleTimeString('en-US', options);

        const match = londonTime.match(/^([^:]*):/); // 例: "3:45 PM"
        hour = parseInt(match[1], 10);
        const ampmMatch = londonTime.match(/ (AM|PM)/i);
        const ampm = ampmMatch ? ampmMatch[1].toLowerCase() : '';

        // PMのときはhourを24時間に換算
        if (ampm === 'pm' && hour !== 12) hour += 12;
        if (ampm === 'am' && hour === 12) hour = 0;
    }

    // 昼間マーク（6〜17時）を追加
    let isDaytime = (hour >= 6 && hour < 18) ? ' *' : '';

    // compare only the dates without considering time
    const londonDateWithoutTime = new Date(londonDate.getFullYear(), londonDate.getMonth(), londonDate.getDate());
    const currentDateWithoutTime = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());

    // add day checker and show
    if (londonDateWithoutTime.getTime() < currentDateWithoutTime.getTime()) {
        worldClock1Element.textContent = `${londonTime}${isDaytime} Previous Day`;
    } else if (londonDateWithoutTime.getTime() > currentDateWithoutTime.getTime()) {
        worldClock1Element.textContent = `${londonTime}${isDaytime} Next Day`;
    } else {
        worldClock1Element.textContent = londonTime + isDaytime;
    }

    cityNameElement.textContent = TimeZone2;
}


// 1秒ごとに worldClockOne を実行するタイマー
setInterval(() => {
    worldClockOne();
    worldClockTwo();
}, 1000);