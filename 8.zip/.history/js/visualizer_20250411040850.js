function wallpaperAudioListener(audioArray) {

    const volumeValue = parseFloat(volumeElement.textContent);

    if (volumeValue === 0.00) {
        audioPaused = true;
        statusDiv.textContent = 'paused';
        statusDiv.style.opacity = 0.25;
        line1opacity.style.opacity = 0.25;
        artist.style.opacity = 0.25;
        duration.style.opacity = 0.25;
        volumeElement.style.opacity = 0.25;
        albumName.style.opacity = 0.25;
    } else {
    
        if (albumNameInvalid) {
            audioPaused = false;
            statusDiv.textContent = 'playing';
            statusDiv.style.opacity = 1;
            line1opacity.style.opacity = 1;
            artist.style.opacity = 1;
            duration.style.opacity = 1;
            volumeElement.style.opacity = 1;
            albumName.style.opacity = 0.25;
        } else {
            audioPaused = false;
            statusDiv.textContent = 'playing';
            statusDiv.style.opacity = 1;
            line1opacity.style.opacity = 1;
            artist.style.opacity = 1;
            duration.style.opacity = 1;
            volumeElement.style.opacity = 1;
            albumName.style.opacity = 1;
        }
    }
        
    audioArray = audioArray.map(value => value * sliderValue);
    
    const average = audioArray.reduce((acc, val) => acc + val, 0) / audioArray.length;
    const maxAudioValue = Math.max(...audioArray);
    volumeElement.textContent = (Math.min(maxAudioValue * 100, 100)).toFixed(2).padEnd(5, '.00').replace(/\.$/, '');
    
    const width = Math.min(maxAudioValue * 19.5, 19.5);
    visualizerLineElement.style.width = width + 'vh';
    
    audioArray = audioArray.slice(64, 128);
    let audioArray32 = [];
    for (let i = 0; i < audioArray.length; i += 2) {
        let value1 = audioArray[i];
        let value2 = audioArray[i + 1];
        let average = (value1 + value2) / 2;
        audioArray32.push(average);
    }

    const barContainer = document.getElementById('audioBars');
    
    barContainer.innerHTML = '';
    audioArray32.forEach((value, index) => {
        const bar = document.createElement('div');

        bar.style.height = value * 7 + 'vh'; // bar height
        bar.style.width = '0.7vh'; // bar width
        bar.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
        bar.style.position = 'absolute';
        bar.style.transform = `translateX(${index * 1.104}vh)`; // bar distance
        bar.style.bottom = '0vh';
        // bar.style.left = '81.9vh';
        barContainer.appendChild(bar);
    });
    
}
    
window.wallpaperRegisterAudioListener(wallpaperAudioListener);