let uiscale;
let sliderValue;
let audioPaused = true;
let use24clock = true;
let showSeconds = true;
let lockui = false;
let albumNameInvalid;
let color = [255, 255, 255];

let useFahrenheit = false;
let latitude = 35.652832;
let longitude = 139.839478;
let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
let apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code&hourly=precipitation_probability&timezone=${encodeURIComponent(timezone)}&forecast_days=1`;

let TimeZone1 = 'Europe/London';
let TimeZone2 = 'America/New_York';

let port = '5000';
let monitorA = 'cpu';
let monitorB = 'ram';
let monitorC = 'gpu';
let monitorD = 'c';

let loadingIcon = document.querySelector('.loading-icon');
let tinyLines = document.querySelectorAll('.tiny-line');
let tinyLine = document.getElementById('tiny-line-1');
let tinyLine2 = document.getElementById('tiny-line-2');
let virticalLine = document.querySelector('.virtical-line');
let audioBars = document.querySelector('.visualizer-mask');
let mediaInfo = document.querySelector('.media-info');
let tinyLine3 = document.getElementById('tiny-line-3');
let tinyLine4 = document.getElementById('tiny-line-4');
let tinyLine5 = document.getElementById('tiny-line-5');
let duration = document.querySelector('.duration');
let albumName = document.querySelector('.album-name');
let albumCover = document.querySelector('.album-cover');
let albumCoverArt = document.getElementById('albumCoverArt');
let trackTitle = document.querySelector('.song-title');
let artist = document.querySelector('.artist-name');
let statusDiv = document.querySelector('.status');
let volumeElement = document.querySelector('.volume');
let visualizerLineElement = document.querySelector('.visualizer-line');
let line1opacity = document.getElementById('line1');
let img = document.getElementById('fullScreenImage');
let flex = document.querySelector('.flex');
let line = document.querySelector('.line');
let lineShadow = document.querySelectorAll('.line-shadow');
let visualizerMask = document.querySelector('.visualizer-mask');
let processLineElement = document.querySelector('.process-line');

window.wallpaperPropertyListener = {
    applyUserProperties: function(properties) {
        if (properties.schemecolor) {
            color = properties.schemecolor.value.split(' ');
            color = color.map(function(c) {
                return Math.ceil(c * 255);
            });
            
            document.body.style.color = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
            line.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
            visualizerLineElement.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
            processLineElement.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
            virticalLine.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
            albumCover.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]}, 0.25)`;
            tinyLines.forEach(line => {
                line.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
            });
            lineShadow.forEach(line => {
                line.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
            });
        }
        if (properties.responsiveness) {
            sliderValue = properties.responsiveness.value;
        } 
        if (properties.uiscale) {
            uiscale = properties.uiscale.value;
            document.body.style.transform = `scale(${100 * uiscale}%, ${100 * uiscale}%)`;
            img.style.transform = `scale(${100 / uiscale}%, ${100 / uiscale}%)`;
        } 
        
        if (properties.customimage) {
            if (!properties.customimage.value) {
                img.src = `wallpaper.jpg`;
                if (img.width > img.height) {
                img.style.height = '100%';
                } else {
                img.style.width = '100%';
                }
            } else {
                img.src = `file:///` + properties.customimage.value;
                if (img.width > img.height) {
                img.style.height = '100%';
                } else {
                img.style.width = '100%';
                }
            }

        }
        
        if (properties.lockui) {
            lockui = properties.lockui.value;
        }

        if (properties.use24h) {
            use24clock = properties.use24h.value;
        }
        
        if (properties.showsec) {
            showSeconds = properties.showsec.value;
        }
        
        if (properties.port) {
          port = properties.port.value;
        }
        if (properties.monitora) {
            monitorA = properties.monitora.value;
        }
        if (properties.monitorb) {
          monitorB = properties.monitorb.value;
        }
        if (properties.monitorc) {
          monitorC = properties.monitorc.value;
        }
        if (properties.monitord) {
          monitorD = properties.monitord.value;
        }
        if (properties.timezone) {
            TimeZone1 = properties.timezone.value;
        }
        
        if (properties.timezone2) {
            TimeZone2 = properties.timezone2.value;
        }
        if (properties.usefahrenheit) {
            useFahrenheit = properties.usefahrenheit.value;
        }
        if (properties.latitude) {
          latitude = parseFloat(properties.latitude.value);
        }
        if (properties.longitude) {
            longitude = parseFloat(properties.longitude.value);
        }
        apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code&hourly=precipitation_probability&timezone=${encodeURIComponent(timezone)}&forecast_days=1`;
        fetchWeatherData()
    },
};

async function fetchWeatherData() {
  try {
      const response = await fetch(apiUrl);
      const data = await response.json();
      
      displayCurrentWeather(data.current); // currentHourを渡す
      console.log('Weather data updated');
  } catch (error) {
      console.error('Error fetching weather data:', error);
  }
}

function getWeatherDescription(weatherCode) {
  const weatherDescriptions = {
      0: "Clear",
      1: "Mainly Clear",
      2: "Partly Cloudy",
      3: "Cloudy",
      45: "Foggy",
      48: "Rime Fog",
      51: "Light Drizzle",
      53: "Drizzle",
      55: "Heavy Drizzle",
      56: "Light Freezing Drizzle",
      57: "Freezing Drizzle",
      61: "Light Rain",
      63: "Rain",
      65: "Heavy Rain",
      66: "Light Freezing Rain",
      67: "Freezing Rain",
      71: "Slight Snow",
      73: "Snow",
      75: "Heavy Snow",
      77: "Snow Grains",
      80: "Light Showers",
      81: "Showers",
      82: "Heavy Showers",
      85: "Light Snow Showers",
      86: "Snow Showers",
      95: "Thunderstorm",
      96: "Light Thunderstorm With Hail",
      99: "Thunderstorm With Hail"
  };
  return weatherDescriptions[weatherCode] || "Unknown";
}

function displayCurrentWeather(current) {
  const tempDiv = document.querySelector('.temp');
  const forecastDiv = document.querySelector('.forecast');
  const currentTemp = current.temperature_2m;
  const currentWeatherCode = current.weather_code;
  if (useFahrenheit) {
    forecastDiv.textContent = getWeatherDescription(currentWeatherCode);
    tempDiv.textContent = ((currentTemp * 9/5) + 32).toFixed(1) + '\'F';
  } else {
    forecastDiv.textContent = getWeatherDescription(currentWeatherCode);
    tempDiv.textContent = currentTemp + '\'C';
  }
}

setInterval(fetchWeatherData, 600000);
fetchWeatherData();






let isDragging = false;
let dragged = false;
let startX = 0;
let startY = 0;
let currentX = 0;
let currentY = 0;

let clickCount = 0;
let clickTimer = null;

window.addEventListener('DOMContentLoaded', () => {
    const savedX = parseFloat(localStorage.getItem('dragX'));
    const savedY = parseFloat(localStorage.getItem('dragY'));
  
    if (!isNaN(savedX) && !isNaN(savedY)) {
      currentX = savedX;
      currentY = savedY;
      flex.style.transform = `translate(${currentX}px, ${currentY}px)`;
      line.style.transform = `translate(${currentX}px, ${currentY}px)`;
      visualizerMask.style.transform = `translate(${currentX}px, ${currentY}px)`;
    }
});

// ドラッグ開始
const startDrag = (e) => {
  if (lockui) return;
  isDragging = true;
  dragged = false;
  startX = e.clientX;
  startY = e.clientY;
};

// ドラッグ中
const onDrag = (e) => {
    if (!isDragging || lockui) return;

  const dx = e.clientX - startX;
  const dy = e.clientY - startY;

  if (Math.abs(dx) > 2 || Math.abs(dy) > 2) {
    dragged = true; // 明確にマウスを動かしてる場合に true
  }

  currentX += dx / uiscale;
  currentY += dy / uiscale;

  const maxLeft = window.innerWidth / 2 - line.clientWidth * uiscale / 2;
  const maxTop = window.innerHeight / 2 - line.clientWidth * uiscale / 6;
  console.log(flex.clientWidth);

  currentX = Math.max(-maxLeft, Math.min(maxLeft, currentX));
  currentY = Math.max(-maxTop, Math.min(maxTop, currentY));

  flex.style.transform = `translate(${currentX}px, ${currentY}px)`;
  line.style.transform = `translate(${currentX}px, ${currentY}px)`;
  visualizerMask.style.transform = `translate(${currentX}px, ${currentY}px)`;

  startX = e.clientX;
  startY = e.clientY;

  localStorage.setItem('dragX', currentX);
  localStorage.setItem('dragY', currentY);
};

const endDrag = () => {
  isDragging = false;
};

const handleClick = () => {
  if (dragged) return;

  clickCount++;

  if (clickCount >= 2) {
    resetPosition();
    clearTimeout(clickTimer);
    clickCount = 0;
  } else {
    clickTimer = setTimeout(() => {
      clickCount = 0;
    }, 300);
  }
};

const resetPosition = () => {
  currentX = 0;
  currentY = 0;
  flex.style.transform = `translate(0px, 0px)`;
  line.style.transform = `translate(0px, 0px)`;
  visualizerMask.style.transform = `translate(0px, 0px)`;
  localStorage.setItem('dragX', 0);
  localStorage.setItem('dragY', 0);
};

// イベント登録
[flex, line].forEach(el => {
  el.addEventListener('mousedown', startDrag);
  el.addEventListener('click', handleClick);
});

document.addEventListener('mousemove', onDrag);
document.addEventListener('mouseup', endDrag);





// performance monitor
async function fetchPerformanceData() {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/performance`);
    const data = await response.json();

    function formatCapacity(value) {
      if (value >= 1000) {
        return `${(value / 1024).toFixed(2).replace(/\.?0+$/, '')} TB`;
      }
      return `${value.toFixed(2).replace(/\.?0+$/, '')} GB`;
    }

    const monitors = [monitorA, monitorB, monitorC, monitorD];

    monitors.forEach((monitor, index) => {
      const nameElement = document.querySelector(`.performance-${index + 1}-name`);
      const barElement = document.querySelector(`.performance-line-${index + 1}`);

      if (!nameElement || !barElement) return;

      switch (monitor.toLowerCase()) {
        case 'cpu':
          nameElement.innerText = `CPU: ${data.cpu}%`;
          barElement.style.width = `${data.cpu}%`;
          break;

        case 'ram':
          nameElement.innerText = `RAM: ${data.memory}%`;
          barElement.style.width = `${data.memory}%`;
          break;

        case 'gpu':
          nameElement.innerText = `GPU: ${data.gpu_usage.toFixed(2)}%`;
          barElement.style.width = `${data.gpu_usage}%`;
          break;

        case 'vram':
          nameElement.innerText = `VRAM: ${data.vram_usage.toFixed(2)}%`;
          barElement.style.width = `${data.vram_usage}%`;
          break;

        default:
          // Assume it's a disk name like 'c', 'd', etc.
          const diskKey = `${monitor.toLowerCase()}_disk`;
          if (data[diskKey]) {
            const [used, total] = data[diskKey].split('/').map(parseFloat);
            const usagePercent = (used / total) * 100;
            nameElement.innerText = ` DRIVE (${monitor}): ${formatCapacity(used)} / ${formatCapacity(total)}`;
            barElement.style.width = `${usagePercent}%`;
          } else {
            nameElement.innerText = `${monitor.toUpperCase()}: No data`;
            barElement.style.width = `0%`;
          }
      }
    });
  } catch (error) {
    console.error('Error fetching performance data:', error);
  }
}


window.onload = () => {
  fetchPerformanceData(); // 最初のデータ取得
  setInterval(fetchPerformanceData, 1000); // 1秒ごとにデータを再取得
};







































