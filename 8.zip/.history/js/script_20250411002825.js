let uiscale;
let sliderValue;
let audioPaused = true;
let use24clock = true;
let showSeconds = true;
let lockui = false;
let albumNameInvalid;

let TimeZone1 = 'Europe/London';
let TimeZone2 = 'America/New_York';

let loadingIcon = document.querySelector('.loading-icon');
let tinyLine = document.getElementById('tiny-line-1');
let tinyLine2 = document.getElementById('tiny-line-2');
let virticalLine = document.querySelector('.virtical-line');
let audioBars = document.querySelector('.visualizer-mask');
let mediaInfo = document.querySelector('.media-info');
let tinyLine3 = document.getElementById('tiny-line-3');
let tinyLine4 = document.getElementById('tiny-line-4');
let duration = document.querySelector('.duration');
let albumName = document.querySelector('.album-name');
let albumCover = document.querySelector('.album-cover');
let albumCoverArt = document.getElementById('albumCoverArt');
let trackTitle = document.querySelector('.song-title');
let artist = document.querySelector('.artist-name');
let statusDiv = document.querySelector('.status');
let volumeElement = document.querySelector('.volume');
let visualizerLineElement = document.querySelector('.visualizer-line');
let line1opacity = document.getElementById('line1');
let img = document.getElementById('fullScreenImage');

window.wallpaperPropertyListener = {
    applyUserProperties: function(properties) {
        if (properties.responsiveness) {
            sliderValue = properties.responsiveness.value;
        } 
        if (properties.uiscale) {
            uiscale = properties.uiscale.value;
            document.body.style.transform = `scale(${100 * uiscale}%, ${100 * uiscale}%)`;
            img.style.transform = `scale(${100 / uiscale}%, ${100 / uiscale}%)`;
        } 
        
        if (properties.customimage) {
            if (!properties.customimage.value) {
                img.src = `wallpaper.jpg`;
                if (img.width > img.height) {
                img.style.height = '100%';
                } else {
                img.style.width = '100%';
                }
            } else {
                img.src = `file:///` + properties.customimage.value;
                if (img.width > img.height) {
                img.style.height = '100%';
                } else {
                img.style.width = '100%';
                }
            }

        }
        
        if (properties.lockui) {
            lockui = properties.lockui.value;
        }

        if (properties.use24h) {
            use24clock = properties.use24h.value;
        }
        
        if (properties.showsec) {
            showSeconds = properties.showsec.value;
        }
        
        if (properties.timezone) {
            TimeZone1 = properties.timezone.value;
        }
        
        if (properties.timezone2) {
            TimeZone2 = properties.timezone2.value;
        }
    },
};

const flex = document.querySelector('.flex');
const line = document.querySelector('.line');
const visualizerMask = document.querySelector('.visualizer-mask');

let isDragging = false;
let dragged = false;
let startX = 0;
let startY = 0;
let currentX = 0;
let currentY = 0;

let clickCount = 0;
let clickTimer = null;

window.addEventListener('DOMContentLoaded', () => {
    const savedX = parseFloat(localStorage.getItem('dragX'));
    const savedY = parseFloat(localStorage.getItem('dragY'));
  
    if (!isNaN(savedX) && !isNaN(savedY)) {
      currentX = savedX;
      currentY = savedY;
      flex.style.transform = `translate(${currentX}px, ${currentY}px)`;
      line.style.transform = `translate(${currentX}px, ${currentY}px)`;
      visualizerMask.style.transform = `translate(${currentX}px, ${currentY}px)`;
    }
});

// ドラッグ開始
const startDrag = (e) => {
  if (lockui) return;
  isDragging = true;
  dragged = false;
  startX = e.clientX;
  startY = e.clientY;
};

// ドラッグ中
const onDrag = (e) => {
    if (!isDragging || lockui) return;

  const dx = e.clientX - startX;
  const dy = e.clientY - startY;

  if (Math.abs(dx) > 2 || Math.abs(dy) > 2) {
    dragged = true; // 明確にマウスを動かしてる場合に true
  }

  currentX += dx;
  currentY += dy;

  const maxLeft = window.innerWidth / 2 - (line.clientWidth * uiscale * 1.2) / 2;
  const maxTop = window.innerHeight / 2 - (line.clientWidth * uiscale * 1.2) / 6;
  console.log(flex.clientWidth);

  currentX = Math.max(-maxLeft, Math.min(maxLeft, currentX));
  currentY = Math.max(-maxTop, Math.min(maxTop, currentY));

  flex.style.transform = `translate(${currentX}px, ${currentY}px)`;
  line.style.transform = `translate(${currentX}px, ${currentY}px)`;
  visualizerMask.style.transform = `translate(${currentX}px, ${currentY}px)`;

  startX = e.clientX;
  startY = e.clientY;

  localStorage.setItem('dragX', currentX);
  localStorage.setItem('dragY', currentY);
};

const endDrag = () => {
  isDragging = false;
};

const handleClick = () => {
  if (dragged) return;

  clickCount++;

  if (clickCount >= 2) {
    resetPosition();
    clearTimeout(clickTimer);
    clickCount = 0;
  } else {
    clickTimer = setTimeout(() => {
      clickCount = 0;
    }, 300);
  }
};

const resetPosition = () => {
  currentX = 0;
  currentY = 0;
  flex.style.transform = `translate(0px, 0px)`;
  line.style.transform = `translate(0px, 0px)`;
  visualizerMask.style.transform = `translate(0px, 0px)`;
  localStorage.setItem('dragX', 0);
  localStorage.setItem('dragY', 0);
};

// イベント登録
[flex, line].forEach(el => {
  el.addEventListener('mousedown', startDrag);
  el.addEventListener('click', handleClick);
});

document.addEventListener('mousemove', onDrag);
document.addEventListener('mouseup', endDrag);