let isInfoVisible = localStorage.getItem('isInfoVisible') === 'true';
let isTextVisible = !isInfoVisible;
const toggleTime = 1000;

loadingIcon.addEventListener('click', () => {
    isTextVisible = !isTextVisible;
    toggleTextVisibility("show", ".city-name1", ".world-clock1");
    setTimeout(() => toggleTextVisibility("show", ".city-name2", ".world-clock2"), 300);
    toggleTextVisibility("hide", ".duration", ".album-name");

    // アニメーションを操作する部分を分離
    const toggleElements = () => {
        const opacity = isInfoVisible ? '0' : '1';
        tinyLine.style.opacity = opacity;
        tinyLine2.style.opacity = opacity;
        if (isInfoVisible) {
            $(audioBars).animate({ 'height': '7vh' }, toggleTime, 'easeInOutQuart');
            setTimeout(() => { tinyLine3.style.display = 'block'; tinyLine4.style.display = 'block'; }, 2000);
            setTimeout(() => {
                $(virticalLine).animate({ height: '10.5vh' }, toggleTime, 'easeInOutQuart');
                $(duration).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
                $(albumName).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
                $(albumCover).show().animate({ 'margin-top': '0vh' }, toggleTime, 'easeInOutQuart');
            }, toggleTime);
        } else {
            $(virticalLine).animate({ height: '0vh' }, toggleTime, 'easeInOutQuart');
            $(duration).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', () => $(this).hide());
            $(albumName).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', () => $(this).hide());
            $(albumCover).animate({ 'margin-top': '-9.5vh' }, toggleTime, 'easeInOutQuart', () => $(this).hide());
            $(audioBars).animate({ 'height': '0vh' }, 250, 'easeInOutQuart');
            tinyLine3.style.display = 'none';
            tinyLine4.style.display = 'none';
        }
    };

    setTimeout(toggleElements, isInfoVisible ? toggleTime * 1.75 : 500);

    isInfoVisible = !isInfoVisible;
    localStorage.setItem('isInfoVisible', isInfoVisible);

    loadingIcon.style.pointerEvents = 'none';
    setTimeout(() => loadingIcon.style.pointerEvents = '', 2500);
});

// toggleTextVisibility関数を1つに統一
function toggleTextVisibility(actionType, ...elements) {
    elements.forEach(elementId => {
        const textToHide = document.querySelector(elementId);
        const chars = textToHide.textContent.split('');
        let index = 0;

        function updateText(action) {
            if (action === 'hide') {
                if (index < chars.length) {
                    chars[index] = `<span class="hiddenChars">${chars[index]}</span>`;
                    textToHide.innerHTML = chars.join('');
                    index++;
                    setTimeout(() => updateText('hide'), toggleTime / chars.length);
                } else {
                    textToHide.style.display = 'none';
                }
            } else if (action === 'show') {
                if (index < chars.length) {
                    textToHide.style.display = 'block';
                    const slicedText = chars.slice(0, index + 1).join('');
                    textToHide.innerHTML = slicedText;
                    index++;
                    setTimeout(() => updateText('show'), toggleTime / chars.length);
                }
            }
        }

        // actionTypeを受けて処理を決定
        const action = actionType === "show" && !isTextVisible ? 'show' : 'hide';
        if (action === 'show') {
            setTimeout(() => updateText('show'), 1000);
        } else {
            updateText('hide');
        }
    });
}
