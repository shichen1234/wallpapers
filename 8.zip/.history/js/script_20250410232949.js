let sliderValue;
let audioPaused = true;
let use24clock = true;
let showSeconds = true;
let albumNameInvalid;

let TimeZone1 = 'Europe/London';
let TimeZone2 = 'America/New_York';

let loadingIcon = document.querySelector('.loading-icon');
let tinyLine = document.getElementById('tiny-line-1');
let tinyLine2 = document.getElementById('tiny-line-2');
let virticalLine = document.querySelector('.virtical-line');
let audioBars = document.querySelector('.visualizer-mask');
let mediaInfo = document.querySelector('.media-info');
let tinyLine3 = document.getElementById('tiny-line-3');
let tinyLine4 = document.getElementById('tiny-line-4');
let duration = document.querySelector('.duration');
let albumName = document.querySelector('.album-name');
let albumCover = document.querySelector('.album-cover');
let albumCoverArt = document.getElementById('albumCoverArt');
let trackTitle = document.querySelector('.song-title');
let artist = document.querySelector('.artist-name');
let statusDiv = document.querySelector('.status');
let volumeElement = document.querySelector('.volume');
let visualizerLineElement = document.querySelector('.visualizer-line');
let line1opacity = document.getElementById('line1');
let img = document.getElementById('fullScreenImage');

window.wallpaperPropertyListener = {
    applyUserProperties: function(properties) {
        if (properties.responsiveness) {
        sliderValue = properties.responsiveness.value;
        } 
        
        if (properties.customimage) {
            if (!properties.customimage.value) {
                img.src = `wallpaper.jpg`;
                if (img.width > img.height) {
                img.style.height = '100%';
                } else {
                img.style.width = '100%';
                }
            } else {
                img.src = `file:///` + properties.customimage.value;
                if (img.width > img.height) {
                img.style.height = '100%';
                } else {
                img.style.width = '100%';
                }
            }

        }
        
        if (properties.use24h) {
            use24clock = properties.use24h.value;
        }
        
        if (properties.showsec) {
            showSeconds = properties.showsec.value;
        }
        
        if (properties.timezone) {
            TimeZone1 = properties.timezone.value;
        }
        
        if (properties.timezone2) {
            TimeZone2 = properties.timezone2.value;
        }

        if (properties.zoomui) {
            let zoom = properties.zoomui.value;
            if (zoom) {
                document.body.style.transform = 'scale(115%, 115%)';
                img.style.transform = 'scale(87%, 87%)';
            } else {
                document.body.style.transform = '';
                img.style.transform = '';
            }
        }
    },
};


const flex = document.querySelector('.flex');
const line = document.querySelector('.line');

let isDragging = false;
let offset = { x: 0, y: 0 };

// 対象要素を1つにまとめて処理
[flex, line].forEach(element => {
  element.addEventListener('mousedown', (e) => {
    isDragging = true;
    offset.x = e.clientX - flex.offsetLeft;
    offset.y = e.clientY - flex.offsetTop;
  });
});

document.addEventListener('mousemove', (e) => {
  if (!isDragging) return;

  const x = e.clientX - offset.x;
  const y = e.clientY - offset.y;

  flex.style.left = `${x}px`;
  flex.style.top = `${y}px`;

  line.style.left = `${x}px`;
  line.style.top = `${y}px`;
});

document.addEventListener('mouseup', () => {
  isDragging = false;
});