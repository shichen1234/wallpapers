function wallpaperAudioListener(audioArray) {

    const volumeValue = parseFloat(volumeElement.textContent);

    if (volumeValue === 0.00) {
        audioPaused = true;
        statusDiv.textContent = 'paused';
        statusDiv.style.opacity = 0.25;
        line1opacity.style.opacity = 0.25;
        artist.style.opacity = 0.25;
        duration.style.opacity = 0.25;
        volumeElement.style.opacity = 0.25;
        albumName.style.opacity = 0.25;
    } else {
    
        if (albumNameInvalid) {
            audioPaused = false;
            statusDiv.textContent = 'playing';
            statusDiv.style.opacity = 1;
            line1opacity.style.opacity = 1;
            artist.style.opacity = 1;
            duration.style.opacity = 1;
            volumeElement.style.opacity = 1;
            albumName.style.opacity = 0.25;
        } else {
            audioPaused = false;
            statusDiv.textContent = 'playing';
            statusDiv.style.opacity = 1;
            line1opacity.style.opacity = 1;
            artist.style.opacity = 1;
            duration.style.opacity = 1;
            volumeElement.style.opacity = 1;
            albumName.style.opacity = 1;
        }
    }
        
    audioArray = audioArray.map(value => value * sliderValue);
    
    const average = audioArray.reduce((acc, val) => acc + val, 0) / audioArray.length;
    const maxAudioValue = Math.max(...audioArray);
    volumeElement.textContent = (Math.min(maxAudioValue * 100, 100)).toFixed(2).padEnd(5, '.00').replace(/\.$/, '');
    
    const width = Math.min(maxAudioValue * 19.5, 19.5);
    visualizerLineElement.style.width = width + 'vh';
    
    audioArray = audioArray.slice(64, 128);
    let audioArray32 = [];
    for (let i = 0; i < audioArray.length; i += 2) {
        let value1 = audioArray[i];
        let value2 = audioArray[i + 1];
        let average = (value1 + value2) / 2;
        audioArray32.push(average);
    }

    const barContainer = document.getElementById('audioBars');
    
    barContainer.innerHTML = '';
    audioArray32.forEach((value, index) => {
        const bar = document.createElement('div');

        bar.style.height = value * 7 + 'vh'; // bar height
        bar.style.width = '0.7vh'; // bar width
        bar.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
        bar.style.position = 'absolute';
        bar.style.transform = `translateX(${index * 1.104}vh)`; // bar distance
        bar.style.bottom = '0vh';
        // bar.style.left = '81.9vh';
        barContainer.appendChild(bar);
    });
    
}
    

let test = $('.song-title');
let gap = 30;
let animationTimer;

// song title, artist, album name
function wallpaperMediaPropertiesListener(event) {
    if (!event.title) {
        test.text('\u200B');
        $('.test-copy').remove(); // Remove any cloned text
        clearInterval(animationTimer); // Clear the animation timer
    } else {
        // reset animation
        test.stop(true);
        test.css('margin-left', 0);

        // set new text. this is supposed to be value of function
        test.text(event.title);
        var testWidth = test.outerWidth();

        // clone text
        $('.test-copy').remove();
        if (testWidth > $('#line1').width()) {
            test
                .clone()
                .css({ 'margin-left': gap, 'font-size': '1.05vh' })
                .removeClass()
                .addClass('test-copy')
                .insertAfter(test);
        }

        // move text
        let speed = 5;

        function shiftingAnimation() {
            animationTimer = setTimeout(() => {
                testWidth = test.outerWidth(); // Update testWidth if it changes
                if (testWidth > $('#line1').width()) {
                    test.animate({ 'margin-left': -(testWidth + gap) }, {
                        duration: Math.abs((testWidth + gap) * 100 / speed),
                        easing: 'linear',
                        complete: function () {
                            test.css({ 'margin-left': 0 });
                            shiftingAnimation();
                        }
                    });
                } else {
                    clearInterval(animationTimer); // Clear the animation if condition is no longer met
                }
            }, 3000);
        }

        // Check if the condition is met initially or within the 3-second delay
        if (testWidth > $('#line1').width()) {
            clearInterval(animationTimer); // Clear previous timer
            shiftingAnimation();
        } else if (animationTimer) {
            clearInterval(animationTimer); // Clear the animation timer if condition changes within the delay
        }
    }

    if (!event.artist) {
        artist.textContent = '\u200B';
    } else {
        var artistCheck = event.artist;
        if (artistCheck.endsWith(" - Topic")) {
            artistCheck = artistCheck.slice(0, -8);
        }

        artist.textContent = artistCheck;
        artist.style.textOverflow = 'ellipsis';
        artist.style.overflow = 'hidden';
        artist.style.whiteSpace = 'nowrap';
    }

    if (!event.albumTitle) {
        albumName.textContent = 'album: no album title detected';
        albumNameInvalid = true;
    } else {
        albumNameInvalid = false;
        albumName.textContent = 'album: ' + event.albumTitle;
        albumName.style.textOverflow = 'ellipsis';
        albumName.style.overflow = 'hidden';
        albumName.style.whiteSpace = 'nowrap';
    }
}

function wallpaperMediaThumbnailListener(event) {
    albumCoverArt.src = event.thumbnail;
    albumCoverArt.style.height = '100%';
}

// song duration
function wallpaperMediaTimelineListener(event) {
    let seconds = event.duration || 0;
    let hours = Math.floor(seconds / 3600);
    let minutes = Math.floor((seconds % 3600) / 60);
    let sec = seconds % 60;
    let formattedDuration = '';
    if (hours > 0) {
        formattedDuration = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    } else {
        formattedDuration = `${minutes}:${sec.toString().padStart(2, '0')}`;
    }
    
    duration.textContent = `///// ${formattedDuration}`;
}

window.wallpaperRegisterMediaPropertiesListener(wallpaperMediaPropertiesListener);
window.wallpaperRegisterMediaThumbnailListener(wallpaperMediaThumbnailListener);
window.wallpaperRegisterMediaTimelineListener(wallpaperMediaTimelineListener);
window.wallpaperRegisterAudioListener(wallpaperAudioListener);