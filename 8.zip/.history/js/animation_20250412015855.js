// 初期状態をlocalStorageから読み込む。存在しない場合はデフォルト値を使用
let isInfoVisible = localStorage.getItem('isInfoVisible') !== null ? JSON.parse(localStorage.getItem('isInfoVisible')) : true;
let isTextVisible = !isInfoVisible;
let toggleTime = 1000;
let state = 0;

// ページ読み込み時に保存された状態を復元
document.addEventListener('DOMContentLoaded', function() {
    restoreVisibilityState();
});

function saveVisibilityState() {
    localStorage.setItem('isInfoVisible', JSON.stringify(isInfoVisible));
}

function restoreVisibilityState() {
    if (!isInfoVisible) {
        // 非表示状態だった場合、即座に要素を非表示にする
        document.querySelectorAll(".city-name1, .world-clock1, .city-name2, .world-clock2, .temp, .forecast").forEach(el => {
            el.style.display = 'none';
        });
        document.querySelectorAll(".duration, .album-name").forEach(el => {
            el.style.display = 'block';
        });
        
        tinyLine.style.opacity = '0';
        tinyLine2.style.opacity = '0';
        tinyLine3.style.display = 'block';
        tinyLine4.style.display = 'block';
        tinyLine5.style.opacity = '0';
        virticalLine.style.height = '10.5vh';
        duration.style.top = '8vh';
        albumName.style.top = '8vh';
        albumCover.style.marginTop = '0vh';
        audioBars.style.height = '7vh';
    }
}

loadingIcon.addEventListener('click', function() {
    if (monitor) {
        state = (state + 1) % 3; // 0 → 1 → 2 → 0…
    } else {
        state = state === 0 ? 1 : 0;
    }

    if (state === 1) {
        // hide world clock & weather
        toggleTextVisibility(".city-name1", ".world-clock1");
        setTimeout(() => toggleTextVisibility(".city-name2", ".world-clock2"), 150);
        setTimeout(() => toggleTextVisibility(".temp", ".forecast"), 300);
        toggleTextVisibility(".duration", ".album-name");
        setTimeout(function() {tinyLine.style.opacity = '0';}, toggleTime * 0.33);
        setTimeout(function() {tinyLine2.style.opacity = '0';}, toggleTime * 0.66);
        setTimeout(function() {tinyLine5.style.opacity = '0';}, toggleTime * 1);
        setTimeout(function() {$(audioBars).animate({ 'height': '7vh' }, toggleTime, 'easeInOutQuart');}, toggleTime * 1.75);

        // show media info
        setTimeout(() => {
            tinyLine3.style.display = 'block';
            tinyLine4.style.display = 'block';
        }, 2000);
        setTimeout(function() {
            $(virticalLine).animate({ height: '10.5vh' }, toggleTime, 'easeInOutQuart');
            $(duration).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumName).show().animate({ top: '8vh' }, toggleTime, 'easeInOutQuart');
            $(albumCover).show().animate({ 'margin-top': '0vh' }, toggleTime, 'easeInOutQuart');
        }, toggleTime);
    } else if (state === 2 && monitor) {
        // hide media info
        tinyLine3.style.display = 'none';
        tinyLine4.style.display = 'none';
        $(virticalLine).animate({ height: '0vh' }, toggleTime, 'easeInOutQuart');
        $(duration).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(albumName).animate({ top: '0vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(albumCover).animate({ 'margin-top': '-9.5vh' }, toggleTime, 'easeInOutQuart', function() {$(this).hide();});
        $(audioBars).animate({ 'height': '0vh' }, 250, 'easeInOutQuart');

        // show performance monitor
        toggleTextVisibility(".duration", ".album-name");
        document.querySelectorAll(".performance-line").forEach(el => el.style.display = 'block');
        document.querySelectorAll(".performance-name").forEach(el => toggleTextVisibility(`#${el.id}`));
        document.querySelectorAll(".line-shadow-2").forEach(el => el.style.width = '100%');
        document.querySelector("#tiny-line-6").style.opacity = '1';
        document.querySelector("#tiny-line-7").style.opacity = '1';
    } else {
        // hide performance monitor
        toggleTextVisibility(".duration", ".album-name");
        document.querySelectorAll(".performance-line").forEach(el => el.style.display = 'none');
        document.querySelectorAll(".performance-name").forEach(el => toggleTextVisibility(`#${el.id}`));
        document.querySelectorAll(".line-shadow-2").forEach(el => el.style.width = '0%');
        document.querySelector("#tiny-line-6").style.opacity = '0';
        document.querySelector("#tiny-line-7").style.opacity = '0';

        // show world clock & weather
        document.querySelectorAll(".performance-name").forEach(el => toggleTextVisibility(`#${el.id}`));
        toggleTextVisibility(".city-name1", ".world-clock1");
        setTimeout(() => toggleTextVisibility(".city-name2", ".world-clock2"), 150);
        setTimeout(() => toggleTextVisibility(".temp", ".forecast"), 300);
        setTimeout(function() {
            setTimeout(function() {tinyLine.style.opacity = '1';}, toggleTime * 0.33);
            setTimeout(function() {tinyLine2.style.opacity = '1';}, toggleTime * 0.66);
            setTimeout(function() {tinyLine5.style.opacity = '1';}, toggleTime * 1);
        }, 500);
    

    }

    loadingIcon.style.pointerEvents = 'none';
    setTimeout(function() {
        loadingIcon.style.pointerEvents = '';
    }, 2500);
});


function toggleTextVisibility(...elements) {
    elements.forEach(elementId => {
        const textElement = document.querySelector(elementId);
        if (!textElement) return;

        const isCurrentlyVisible = textElement.style.display !== 'none';
        const chars = textElement.textContent.split('');
        let index = 0;

        function updateText(action) {
            if (action === 'hide') {
                if (index < chars.length) {
                    chars[index] = `<span class="hiddenChars">${chars[index]}</span>`;
                    textElement.innerHTML = chars.join('');
                    index++;
                    setTimeout(() => updateText('hide'), toggleTime / chars.length);
                } else {
                    textElement.style.display = 'none';
                }
            } else if (action === 'show') {
                if (index < chars.length) {
                    textElement.style.display = 'block';
                    const slicedText = chars.slice(0, index + 1).join('');
                    textElement.innerHTML = slicedText;
                    index++;
                    setTimeout(() => updateText('show'), toggleTime / chars.length);
                }
            }
        }

        if (isCurrentlyVisible) {
            updateText('hide');
        } else {
            setTimeout(() => updateText('show'), 1000);
        }
    });
}

