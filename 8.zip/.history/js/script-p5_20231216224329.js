let angle = 0;
let rotationSpeed = 0.02;
let pg;
let x = 0
let y = 125;
let isMousePressed = false;
let originalArcRadius = 28;
let originalEllipseRadius = 23;
let mouseEnabled = true;

function setup() {
    pixelDensity(2);
    let canvas = createCanvas(30, 30);
    canvas.parent('blinkButton'); // canvasを指定のdivに追加する
    canvas.style('position', 'absolute');
    canvas.style('width', '100%'); // canvasの幅を親要素の幅に合わせる
    canvas.style('height', '100%');
    canvas.style('z-index', '-1');
    pg = createGraphics(30, 30);
  }

function draw() {
    clear();
    background(220, 0);
    translate(15, 15);

    let arcRadius = isMousePressed ? originalArcRadius * 0.9 : originalArcRadius;
    let ellipseRadius = isMousePressed ? originalEllipseRadius * 0.9 : originalEllipseRadius;
    
    let volumeElement = document.querySelector('.volume');
    let volumeValue = parseInt(volumeElement.innerText); // Convert text to number
    
    rotate(angle);
    
    // createGraphicsの背景色を赤に設定し赤い四角を描画
    pg.clear();
    pg.noStroke();
    pg.fill(255);
    pg.arc(15, 15, arcRadius, arcRadius, radians(100), radians(260), CHORD);
    pg.arc(15, 15, arcRadius, arcRadius, radians(280), radians(440), CHORD);

    // 円形に取り除く
    pg.erase();
    pg.ellipse(pg.width/2, pg.height/2, ellipseRadius, ellipseRadius);
    pg.noErase();

    // pgをimageとして配置
    image(pg, -15, -15);

    if (!audioPaused) {
        angle += rotationSpeed;
    }
}

function mousePressed() {
    if (mouseEnabled) {
      isMousePressed = true;
      mouseEnabled = false; // マウスイベントを無効化
  
      setTimeout(function() {
        mouseEnabled = true; // 3秒後にマウスイベントを有効化
      }, 2600); // 3秒間待機
    }
}
  
function mouseReleased() {
// Check if the mouse is within the bounds of the pg (30x30 area)
if (mouseX >= 0 && mouseX < 30 && mouseY >= 0 && mouseY < 30) {
    isMousePressed = false;
}
}