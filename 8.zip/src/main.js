//目前可用配置
var allConfigure = [
	"KitHitokoto",
	"sakura",
	"wallpapermode",
	"DefaultWallpaper",
	"ImageFile",
	"timecolor"
]

//保存 AND 读取当前配置
function setConfigure(name,values) {
	localStorage.setItem(name,values);
};
function getConfigure(name) {
	if(localStorage.getItem(name) != null) {
		return localStorage.getItem(name);
	} else if (name == "DefaultWallpaper") {
		return "1";
	} else if (name == "wallpapermode") {
		return "1";
	} else if (name == "timecolor"){
		return "156, 39, 176";
	}
};

//全局变量
var KitHitokoto = document.getElementById("hitokotoClose");
var sakura = document.getElementById("sakura");
var DefaultWallpaper = document.getElementById("bg");
var timecolor = document.getElementById("timeblock");

//读取用户设置
$(document).ready(function() {
	KitHitokoto.style.display = getConfigure(allConfigure[0]);
	sakura.style.display = getConfigure(allConfigure[1]);
	if(getConfigure(allConfigure[2]) == "1"){
		DefaultWallpaper.style.backgroundImage = "url(./Images/"+ getConfigure(allConfigure[3])+".jpg)";
	} else {
		DefaultWallpaper.style.backgroundImage = "url('"+'file:///' + getConfigure(allConfigure[4]) + "')";
	}
	timecolor.style.color = "rgb("+getConfigure(allConfigure[5])+")";
});

//监听壁纸配置
window.wallpaperPropertyListener = {
	applyUserProperties: function(properties) {
		//是否显示一言
		if(properties.KitHitokoto){
			if(properties.KitHitokoto.value == "1"){
				KitHitokoto.style.display= "block";
				setConfigure("KitHitokoto","block");
			}else{
				KitHitokoto.style.display= "none";
				setConfigure("KitHitokoto","none");
			}
		};
		//是否开启动态效果
		if(properties.sakura){
			if(properties.sakura.value == "1"){
				sakura.style.display= "block";
				setConfigure("sakura","block");
			}else{
				sakura.style.display= "none";
				setConfigure("sakura","none");
			}
		};
		//壁纸模式
		if(properties.wallpapermode){
			setConfigure("wallpapermode",properties.wallpapermode.value);
		};
		//设置壁纸
		if(properties.DefaultWallpaper){
			DefaultWallpaper.style.backgroundImage = "url(./Images/"+properties.DefaultWallpaper.value+".jpg)";
			setConfigure("DefaultWallpaper",properties.DefaultWallpaper.value);
		};
		//设置自定义壁纸
		if(properties.ImageFile){
			DefaultWallpaper.style.backgroundImage = "url('"+'file:///' + properties.ImageFile.value + "')";
			setConfigure("ImageFile",properties.ImageFile.value);
		};
		//设置时钟颜色
		if(properties.timecolor){
			var c = properties.timecolor.value.split(' ').map(function(c){return Math.ceil(c*255)})
			timecolor.style.color = "rgb("+c+")";
			setConfigure("timecolor",c);
		}
	}
};