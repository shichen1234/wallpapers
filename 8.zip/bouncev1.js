window.wallpaperPropertyListener = {
  applyUserProperties: function(properties) {

    // ----------------- Jufufu -----------------
    if (properties.jufufuScale) {
      const scale = properties.jufufuScale.value;
      const jufufu = document.getElementById("jufufu");
      if (jufufu) {
        jufufu.style.transform = `scale(${scale})`;
        jufufu.style.transformOrigin = "center center"; // keep centered
      }
    }

    // ----------------- UI Scaling -----------------
    if (properties.uiScale) {
      const scale = properties.uiScale.value;

      // Bottom-left container (credits + volume)
      const bottomLeft = document.getElementById("bottom-left");
      if (bottomLeft) {
        bottomLeft.style.transform = `scale(${scale})`;
        bottomLeft.style.transformOrigin = "bottom left";
      }

      // Bottom-right container (chaos button)
      const chaosBtn = document.getElementById("chaos-toggle");
      if (chaosBtn) {
        chaosBtn.style.transform = `scale(${scale})`;
        chaosBtn.style.transformOrigin = "bottom right";
        chaosBtn.style.fontSize = `${clamp(12, 16 * scale, 20)}px`;
        chaosBtn.style.padding = `${8 * scale}px ${12 * scale}px`;
        chaosBtn.style.whiteSpace = "nowrap";
      }

      // Top-right container (dev overlays button)
      const topRight = document.getElementById("top-right");
      if (topRight) {
        topRight.style.transform = `scale(${scale})`;
        topRight.style.transformOrigin = "top right";
      }

      // Score / stats box scaling
      const statsBox = document.querySelector("div[style*='Bounces']");
      if (statsBox) {
        statsBox.style.transform = `scale(${scale})`;
        statsBox.style.transformOrigin = "top left";
      }
    }

  }
}

// Helper clamp function
function clamp(min, val, max) {
  return Math.min(Math.max(val, min), max);
}



const jufufu = document.getElementById("jufufu");
const toggleBtn = document.getElementById("chaos-toggle");
const volumeControl = document.getElementById("volume-control");

let lastCornerHitTime = 0;
let highScore = Number(localStorage.getItem("jufufuHighscore")) || 0;

let posX = 100;
let posY = 100;
let velX = 3.5;
let velY = 3.5;
let isChaos = false;
let bounceCount = 0;
let cornerHits = 0;
let chaosClickCount = 0;

// BGM + SFX
const bgm = document.getElementById("bgm");
const cornerSFX = document.getElementById("corner-sfx");
const chaosSFX = document.getElementById("chaos-sfx");
const chaosflare = document.getElementById("chaosflare");
const bounceSFX = document.getElementById("bounce-sfx");
const volumeIcon = document.getElementById("volume-icon");

// NEW: separate sliders
const volumeSliderBGM = document.getElementById("volume-slider-bgm");
const volumeSliderSFX = document.getElementById("volume-slider-sfx");

// Vol settings
chaosSFX.volume = 1.0;
cornerSFX.volume = 0.9;
bounceSFX.volume = 0.1;
bgm.volume = 0.3;
chaosflare.volume = 0.2;
bgm.muted = true;
chaosflare.muted = true;
let audioUnlocked = false;

bgm.play().catch(() => {});
chaosflare.pause();

function updateVolumeIcon(vol) {
  volumeIcon.src = vol === 0 ? "img/volumeMuted.png" : "img/volume.png";
}

// Separate volume control functions
function setBGMVolume(vol) {
  bgm.volume = vol;
  chaosflare.volume = vol;
  updateVolumeIcon(vol);
}

function setSFXVolume(vol) {
  bounceSFX.volume = vol;
}

// Unlock audio on first interaction
function unlockAudio() {
  if (audioUnlocked) return;
  audioUnlocked = true;

  bgm.muted = false;
  chaosflare.muted = false;

  if (!isChaos) {
    bgm.currentTime = 0;
    bgm.loop = true;
    bgm.play().catch(err => console.log("BGM blocked:", err));
    chaosflare.pause();
  } else {
    chaosflare.currentTime = 0;
    chaosflare.loop = true;
    chaosflare.play().catch(err => console.log("Chaos music blocked:", err));
    bgm.pause();
  }

  setBGMVolume(parseFloat(volumeSliderBGM.value));
  setSFXVolume(parseFloat(volumeSliderSFX.value));
}


// Slider events
volumeSliderBGM.addEventListener("input", () => {
  const vol = parseFloat(volumeSliderBGM.value);
  setBGMVolume(vol);
  unlockAudio();
});

volumeSliderSFX.addEventListener("input", () => {
  const vol = parseFloat(volumeSliderSFX.value);
  setSFXVolume(vol);
  unlockAudio();
});

// Click to mute/unmute both
volumeIcon.addEventListener("click", () => {
  const isMuted = volumeSliderBGM.value === "0" && volumeSliderSFX.value === "0";
  if (isMuted) {
    volumeSliderBGM.value = "0.5";
    volumeSliderSFX.value = "0.5";
  } else {
    volumeSliderBGM.value = "0";
    volumeSliderSFX.value = "0";
  }
  volumeSliderBGM.dispatchEvent(new Event("input"));
  volumeSliderSFX.dispatchEvent(new Event("input"));
});

jufufu.addEventListener("click", (e) => {
  unlockAudio();
  // Play bounce SFX on click
  bounceSFX.currentTime = 0;
  bounceSFX.play();
});

// Chaos toggle animation
setTimeout(() => {
  toggleBtn.style.animation = "wiggle 0.3s ease-in-out infinite alternate";
}, 5000);

const style = document.createElement("style");
style.textContent = `
@keyframes wiggle {
  from { transform: rotate(-2deg); }
  to { transform: rotate(2deg); }
}`;
document.head.appendChild(style);

// Stats UI
const statsBox = document.createElement("div");
statsBox.style.position = "fixed";
statsBox.style.top = "40px";
statsBox.style.left = "24px";
statsBox.style.background = "rgba(255,255,255,0.65)";
statsBox.style.padding = "6px 14px";
statsBox.style.borderRadius = "12px";
statsBox.style.fontFamily = "monospace";
statsBox.style.fontSize = "1rem";
statsBox.style.color = "#444";
statsBox.style.boxShadow = "0 2px 8px #0001";
statsBox.style.pointerEvents = "none";
statsBox.style.zIndex = 998;
statsBox.style.userSelect = "none";
statsBox.style.transition = "background 0.2s, box-shadow 0.2s";
document.body.appendChild(statsBox);

function updateStats() {
  let stats = `Bounces: ${bounceCount}<br>Corners Hit: ${cornerHits}`;
  if (cornerHits > 0 || highScore > 0) {
    stats += `<br>🏆 High Score: ${highScore}`;
  }
  statsBox.innerHTML = stats;
}

let lastUpdateTime = Date.now();

function updatePosition() {
  const now = Date.now();
  const delta = (now - lastUpdateTime) / 16.67;
  lastUpdateTime = now;

  const imgWidth = jufufu.offsetWidth;
  const imgHeight = jufufu.offsetHeight;
  const screenWidth = window.innerWidth;
  const screenHeight = window.innerHeight;

  posX += velX * delta;
  posY += velY * delta;

  let bouncedX = false;
  let bouncedY = false;

  if (posX + imgWidth >= screenWidth) {
    posX = screenWidth - imgWidth;
    velX *= -1;
    bouncedX = true;
  } else if (posX <= 0) {
    posX = 0;
    velX *= -1;
    bouncedX = true;
  }

  if (posY + imgHeight >= screenHeight) {
    posY = screenHeight - imgHeight;
    velY *= -1;
    bouncedY = true;
  } else if (posY <= 0) {
    posY = 0;
    velY *= -1;
    bouncedY = true;
  }

  if (bouncedX || bouncedY) {
    onBounce(bouncedX, bouncedY);
  }

  jufufu.style.left = `${posX}px`;
  jufufu.style.top = `${posY}px`;

  setTimeout(updatePosition, 16);
}

function onBounce(bouncedX, bouncedY) {
  bounceCount++;
  updateStats();

  const randomFactor = () => (Math.random() - 0.5) * 1.5;
  velX += randomFactor();
  velY += randomFactor();

  const speed = Math.sqrt(velX * velX + velY * velY);
  const baseSpeed = isChaos ? 7 : 3.5;
  velX = (velX / speed) * baseSpeed;
  velY = (velY / speed) * baseSpeed;

  const nearCorner = () => {
    const tolerance = 20;
    const isLeft = posX <= tolerance;
    const isRight = posX + jufufu.offsetWidth >= window.innerWidth - tolerance;
    const isTop = posY <= tolerance;
    const isBottom = posY + jufufu.offsetHeight >= window.innerHeight - tolerance;
    return (isLeft || isRight) && (isTop || isBottom);
  };

  const now = Date.now();
  const timeSinceLastHit = now - lastCornerHitTime;

  if (!nearCorner()) {
    bounceSFX.currentTime = 0;
    bounceSFX.play();
  }

  if (nearCorner()) {
    let addedPoints = 1;
    if (timeSinceLastHit < 500) {
      addedPoints = Math.random() < 0.3 ? 2 : 1;
    }

    cornerHits += addedPoints;
    lastCornerHitTime = now;
    updateStats();
    cornerSFX.play();

    jufufu.style.filter = "brightness(2)";
    setTimeout(() => {
      jufufu.style.filter = "none";
    }, 150);

    if (cornerHits > highScore) {
      highScore = cornerHits;
      localStorage.setItem("jufufuHighscore", highScore);
      statsBox.style.boxShadow = "0 0 10px gold";
      setTimeout(() => {
        statsBox.style.boxShadow = "none";
      }, 500);
    }
  }
}

toggleBtn.addEventListener("click", () => {
  isChaos = !isChaos;
  jufufu.src = isChaos ? "img/Jufu2.gif" : "img/Jufu1.gif";
  toggleBtn.textContent = isChaos ? "Return to Chill Mode" : "Chaos Mode";

  const newSpeed = isChaos ? 5 : 2;
  const speed = Math.sqrt(velX * velX + velY * velY);
  velX = (velX / speed) * newSpeed;
  velY = (velY / speed) * newSpeed;

  chaosSFX.currentTime = 0;
  chaosSFX.play().catch(() => {});

  if (isChaos) {
    // stop bgm
    bgm.pause();
    // start chaos music
    chaosflare.muted = false;
    chaosflare.currentTime = 0;
    chaosflare.loop = true;
    chaosflare.play().catch(err => {
      console.log("Chaos music blocked:", err);
    });
  } else {
    // stop chaos music
    chaosflare.pause();
    chaosflare.loop = false;
    // restart bgm
    bgm.muted = false;
    bgm.currentTime = 0;
    bgm.loop = true;
    bgm.play().catch(err => {
      console.log("BGM blocked:", err);
    });
  }

  chaosClickCount++;
  if (chaosClickCount >= 2) {
    toggleBtn.style.transition = "transform 0.2s ease";
    toggleBtn.style.animation = "none";
    toggleBtn.style.transform = "rotate(0deg)";
  }

  unlockAudio();
});


lastUpdateTime = Date.now();
updatePosition();
updateStats();

// Init sliders to 0
volumeSliderBGM.value = "0";
volumeSliderSFX.value = "0";
updateVolumeIcon(0);

const creditsBtn = document.getElementById("credits-btn");
const creditsOverlay = document.getElementById("credits-overlay");
const creditsContent = document.getElementById("credits-content");

creditsBtn.addEventListener("click", (e) => {
  creditsOverlay.style.display = "flex";
  e.stopPropagation();
});

creditsOverlay.addEventListener("click", () => {
  creditsOverlay.style.display = "none";
});

creditsContent.addEventListener("click", (e) => {
  e.stopPropagation();
});

const devBtn = document.getElementById("dev-disable-overlays");
let overlaysDisabled = false;

devBtn.addEventListener("click", () => {
  overlaysDisabled = !overlaysDisabled;
  statsBox.style.display = overlaysDisabled ? "none" : "";
  creditsBtn.style.display = overlaysDisabled ? "none" : "";
  creditsOverlay.style.display = overlaysDisabled ? "none" : "";
  volumeControl.style.display = overlaysDisabled ? "none" : "";
  toggleBtn.style.display = overlaysDisabled ? "none" : "";
});
