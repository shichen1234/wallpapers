var SCREEN_WIDTH = window.innerWidth;
		var SCREEN_HEIGHT = window.innerHeight;
		var container, particle, poi, camera, scene, renderer, material, isTime, speed, number, numbers, bgSize, imageElement =
			document.getElementsByTagName('body')[0];
		var mouseX = 0;
		var mouseY = 0;
		var windowHalfX = window.innerWidth / 2;
		var windowHalfY = window.innerHeight / 2;
		var particles = [];
		var particleImage = new Image();
		particleImage.src = 'images/ParticleSmoke.png';

		window.wallpaperPropertyListener = {
			applyUserProperties: function (properties) {
				numbers = number;
				if (properties.customcombo) {
					bgSize = properties.customcombo.value;
					imageElement.style.backgroundSize = bgSize;
				}
				if (properties.aSpeed) {
					speed = properties.aSpeed.value;
				}
				if (properties.aNumber) {
					number = properties.aNumber.value;
				}
				if (properties.custombool) {
					if (properties.custombool.value) {
						imageElement.style.backgroundImage = 'url(' + 'images/bg.jpg' + ')';
						properties.customimage.value = "";
					}
				}
				if (properties.customimage) {
					if (properties.customimage.value) {
						imageElement.style.backgroundImage = 'url(' + 'file:///' + properties.customimage.value + ')';
					}
				}
				if (properties.custompink) {
					properties.custompink.value ? particleImage.src = 'images/ParticleSmoke2.png' : particleImage.src =
						'images/ParticleSmoke.png';
				}
				cl();
			}
		};


		function init() {
			container = document.createElement('div');
			document.body.appendChild(container);

			camera = new THREE.PerspectiveCamera(75, SCREEN_WIDTH / SCREEN_HEIGHT, 1, 10000);
			camera.position.z = 1000;

			scene = new THREE.Scene();
			scene.add(camera);

			renderer = new THREE.CanvasRenderer();
			renderer.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
			material = new THREE.ParticleBasicMaterial({
				map: new THREE.Texture(particleImage)
			});
			container.appendChild(renderer.domElement);
		}

		function loop() {
			for (var i = 0; i < particles.length; i++) {

				var particle = particles[i];
				particle.updatePhysics();

				with(particle.position) {
					if (y < -1000) y += 2000;
					if (x > 1000) x -= 2000;
					else if (x < -1000) x += 2000;
					if (z > 1000) z -= 2000;
					else if (z < -1000) z += 2000;
				}
			}
			camera.lookAt(scene.position);
			renderer.clear();
			renderer.render(scene, camera);
		}

		function cl() {
			for (var i = 0; i < numbers; i++) {
				scene.remove(particles[i])
			}
			particles = [];
			clearInterval(isTime);
			for (var i = 0; i < number; i++) {
				particle = new Particle3D(material);
				particle.position.x = Math.random() * 2000 - 1000;
				particle.position.y = Math.random() * 2000 - 1000;
				particle.position.z = Math.random() * 2000 - 1000;
				particle.scale.x = particle.scale.y = 1;
				scene.add(particle);
				particles.push(particle);
			}
			isTime = setInterval(loop, speed / 60);
		}