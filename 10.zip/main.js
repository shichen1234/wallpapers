//定义两个值，存放屏幕的尺寸
var _W;
var _H;

//星星数目
var mini_star_count = 150;
var medium_star_count = 20;
var large_star_count = 7;

//播放器
audio = document.createElement("audio");

//角色音静音
if (localStorage.getItem("role_sound_mute")==null) {
    role_sound_mute = 0;
    localStorage.setItem("role_sound_mute",role_sound_mute);
} else {
    role_sound_mute = localStorage.getItem("role_sound_mute");
}

//bgm静音
if (localStorage.getItem("bgm_mute")==null) {
    bgm_mute = 1;
    localStorage.setItem("bgm_mute",bgm_mute);
} else {
    bgm_mute = localStorage.getItem("bgm_mute");
}

console.log(bgm_mute);

//播放器初始化
audio.src = "sound/高田憂希 - CONTINUE…？.ogg";
audio.loop = true;
audio.volume = 0.4;

//播放器播放函数
function bgm_play(argument) {
    if (bgm_mute == 1) {
        if('fastSeek' in audio){
            audio.fastSeek(currentTime);
        } else {
            audio.currentTime = 0;
        }
        audio.pause();
        return;
    }
    if (!audio.src) {return;}
    audio.play();
}
bgm_play();

//sound 静音按钮初始化
if (role_sound_mute == 0) {
    $("#sound_switch").bootstrapSwitch("state", true);
} else {
    $("#sound_switch").bootstrapSwitch("state", false);
}
$('#sound_switch').on({
    'switchChange.bootstrapSwitch': function(event, state) {
        if ($("#sound_switch").is(":focus") == true) {
            if (role_sound_mute == 1) {
                $("#sound_switch").blur();
                role_sound_mute = 0;
            } else {
                $("#sound_switch").blur();
                role_sound_mute = 1;
            }
            localStorage.setItem("role_sound_mute",role_sound_mute);
        } 
    }
});

//bgm 静音按钮初始化
if (bgm_mute == 0) {
    $("#bgm_switch").bootstrapSwitch("state", true);
} else {
    $("#bgm_switch").bootstrapSwitch("state", false);
}
$('#bgm_switch').on({
    'switchChange.bootstrapSwitch': function(event, state) {
        if ($("#bgm_switch").is(":focus") == true) {
            if (bgm_mute == 1) {
                $("#bgm_switch").blur();
                bgm_mute = 0;
            } else {
                $("#bgm_switch").blur();
                bgm_mute = 1;
            }
            console.log(bgm_mute);
            localStorage.setItem("bgm_mute",bgm_mute);
            bgm_play();
        } 
    }
});

//获取屏幕可见尺寸
function getWindowWH(){
    _W = $(window).width();
    _H = $(window).height();
}

//调整主容器尺寸为屏幕可见尺寸
function setMainSize() {
    $("body").width(_W);
    $("body").height(_H);
}

//调整 canvas 位置
function setCanvasPOS() {
    
}

getWindowWH();

//预加载图片
var ground_image = new Image();
ground_image.src = "ground.png";
var ground_image_canvas = document.createElement("canvas");
ground_image.onload = function () {
    ground_image_canvas.width = ground_image.width;
    ground_image_canvas.height = ground_image.height;
    var ground_image_canvas_context = ground_image_canvas.getContext('2d');
    ground_image_canvas_context.drawImage(ground_image,0,0);
}

var main_frame_image = new Image();
main_frame_image.src = "main_frame_image.png";
var main_frame_image_canvas = document.createElement("canvas");
main_frame_image.onload = function () {
    main_frame_image_canvas.width = main_frame_image.width;
    main_frame_image_canvas.height = main_frame_image.height;
    var main_frame_image_canvas_context = main_frame_image_canvas.getContext('2d');
    main_frame_image_canvas_context.drawImage(main_frame_image,0,0);
}

var role_frame_image = new Image();
role_frame_image.src = "role_frame_image.png";
var role_frame_image_canvas = document.createElement("canvas");
role_frame_image.onload = function () {
    role_frame_image_canvas.width = role_frame_image.width;
    role_frame_image_canvas.height = role_frame_image.height;
    var role_frame_image_canvas_context = role_frame_image_canvas.getContext('2d');
    role_frame_image_canvas_context.drawImage(role_frame_image,0,0);
}

var line_frame = new Image();
line_frame.src = "line_frame.png";
var line_frame_canvas = document.createElement("canvas");
line_frame.onload = function () {
    line_frame_canvas.width = line_frame.width;
    line_frame_canvas.height = line_frame.height;
    var line_frame_canvas_context = line_frame_canvas.getContext('2d');
    line_frame_canvas_context.drawImage(line_frame,0,0);
}


var cat_line_frame = new Image();
cat_line_frame.src = "img/cat_line_frame.png";
var cat_line_frame_canvas = document.createElement("canvas");
cat_line_frame.onload = function () {
    cat_line_frame_canvas.width = cat_line_frame.width;
    cat_line_frame_canvas.height = cat_line_frame.height;
    var cat_line_frame_canvas_context = cat_line_frame_canvas.getContext('2d');
    cat_line_frame_canvas_context.drawImage(cat_line_frame,0,0);
}
//---预加载图片结束

//图像信息
var ground_image_inf = {
    "frame_img" : ground_image_canvas,
    "width" : 1920,
    "height" : 229,
    "frame_width" : 1920,
    "frame_height" : 229,
    "row_count" : 1,
    "col_count" : 1,
    "row_width_height" : [
        [1920,229]
    ]
}

var main_frame_image_inf = {
    "frame_img" : main_frame_image_canvas,
    "width" : 2500,
    "height" : 3479,
    "frame_width" : -1,
    "frame_height" : -1,
    "row_count" : 11,
    "col_count" : -1,
    "row_width_height" : [
        [55,53],
        [242,240],
        [298,303],
        [312,312],
        [350,353],
        [410,402],
        [471,489],
        [473,465],
        [422,259],
        [2500,301],
        [2500,301]
    ],
    "mini_star_inf" : [
        {
            "row" : 0,
            "content" : [0]
        },
        {
            "row" : 0,
            "content" : [1]
        },
        {
            "row" : 0,
            "content" : [2]
        },
        {
            "row" : 0,
            "content" : [3]
        }
    ],
    "medium_star_inf" : [
        {
            "row" : 0,
            "content" : [4]
        },
        {
            "row" : 0,
            "content" : [5]
        },
        {
            "row" : 0,
            "content" : [6]
        },
        {
            "row" : 0,
            "content" : [7]
        },
        {
            "row" : 0,
            "content" : [8]
        },
        {
            "row" : 0,
            "content" : [9]
        }
    ],
    "large_star_inf" : [
        {
            "row" : 1,
            "content" : [0,1,2,3]
        },
        {
            "row" : 2,
            "content" : [0,1,2,3]
        },
        {
            "row" : 3,
            "content" : [0,1,2,3]
        },
        {
            "row" : 4,
            "content" : [0,1,2,3]
        },
        {
            "row" : 5,
            "content" : [0,1,2,3]
        },
        {
            "row" : 6,
            "content" : [0,1,2,3]
        },
        {
            "row" : 7,
            "content" : [0,1,2,3]
        }
    ],
    "cloud_inf" : [
        {
            "row" : 8,
            "content" : [0] 
        },
        {
            "row" : 8,
            "content" : [1] 
        },
        {
            "row" : 8,
            "content" : [2] 
        },
        {
            "row" : 8,
            "content" : [3] 
        },
        {
            "row" : 8,
            "content" : [4] 
        }
    ],
    "rainbow_stripes_inf" : [
            {
                "row" : 9,
                "content" : [0]
            },
            {
                "row" : 10,
                "content" : [0]
            }
        ]
}

var role_frame_image_inf = {
    "frame_img" : role_frame_image_canvas,
    "width" : 7560,
    "height" : 2912,
    "frame_width" : 540,
    "frame_height" : 728,
    "row_count" : 4,
    "col_count" : 14,
    "role_inf" : [
        {
            "row" : 0,
            "walk" : [0,1,2,3],
            "jump" : [4,5,6,7,8,9,10,11,12,13,12,11,10,9,8,7,6,5,4],
        },
        {
            "row" : 1,
            "walk" : [0,1,2,3],
            "jump" : [4,5,6,7,8,9,10,11,12,13,12,11,10,9,8,7,6,5,4],
        },
        {
            "row" : 2,
            "walk" : [0,1,2,3],
            "jump" : [4,5,6,7,8,9,10,11,12,13,12,11,10,9,8,7,6,5,4],
        },
        {
            "row" : 3,
            "walk" : [0,1,2,3],
            "jump" : [4,5,6,7,8,9,10,11,12,13,12,11,10,9,8,7,6,5,4],
        }
    ],
}

var line_inf = {
    "frame_img" : line_frame_canvas,
    "width" : 8160,
    "height" : 219,
    "frame_width" : 255,
    "frame_height" : 219,
    "col_count" : 32
}

var cat_line_inf = {
    "frame_img" : cat_line_frame,
    "width" : 3795,
    "height" : 2700,
    "frame_width" : 345,
    "frame_height" : 225,
    "count" : 127
}
//-----图像信息结束

//重绘速度
var draw_speed = 50;

//绘制函数
function draw(content, context) {
    context.drawImage(content.source,content.s_x,content.s_y,content.s_width,content.s_height,content.x,content.y,content.width,content.height);
}

//star
star_class = {
    "create" : function () {
        var star = {};
        star.source = main_frame_image_canvas;
        star.inf = null;
        star.s_x = 0;
        star.s_y = 0;
        star.s_width = 0;
        star.s_height = 0;
        star.x = 0;
        star.y = 0;
        star.width = 0;
        star.height = 0;
        star.row = 0;
        star.now_kind = 0;
        star.time = 0;
        star.interval = 500;
        star.setspeed = 0;
        star.speed = 0;
        star.anime = false;
        star.now_frame_number = 0;
        star.mouse_response_margin_rect_prop = 1;
       
        star.draw = function (context) {
            star.y += star.speed;
            if (star.anime) {
                star.time += draw_speed;
                if (star.time >= star.interval) {
                    star.time = 0;
                    star.y += star.speed;
                    star.s_x = star.now_frame_number * star.s_width; 
                    star.now_frame_number = star.now_frame_number + 1 > 4 - 1 ? 0 : star.now_frame_number + 1;
                    draw(star,context);
                } else {
                    draw(star,context);
                }
            } else {
                draw(star,context);
            }
        };
        return star;
    },
};
function create_star(speed,length,kind_number,star_inf,anime) {
    var arr = [];
    var star_now_kind = 0;
    var star_x = [];
    star_x.length = length;
    for (var i = 0; i < star_x.length; i++) {
         star_x[i] = Math.floor(Math.random() * _W);
     };
    var star_y = [];
    star_y.length = length;
    for (var i = 0; i < star_y.length; i++) {
         star_y[i] = Math.floor(Math.random() * ((_H / length) / 10) ) + i * (_H / length);
     } 
     star_y.sort(function(a,b){
        return a-b;
    });
    for (var i = 0; i < length; i++) {
        arr[i] = star_class.create();
        if (anime) {
            arr[i].anime = true;
        }
        arr[i].inf = star_inf;
        arr[i].now_kind = star_now_kind;
        arr[i].row = arr[i].inf[star_now_kind].row;
        arr[i].s_width = main_frame_image_inf.row_width_height[arr[i].row][0];
        arr[i].s_height = main_frame_image_inf.row_width_height[arr[i].row][1];
        arr[i].s_x = arr[i].inf[star_now_kind].content[0] * arr[i].s_width;
        var s_y_temp = 0;
        for (var j = 0; j < arr[i].row; j++) {
            s_y_temp += main_frame_image_inf.row_width_height[j][1];
        }
        arr[i].s_y = s_y_temp;
        arr[i].width = arr[i].s_width;
        arr[i].height = arr[i].s_height;
        arr[i].x = star_x[i] - arr[i].width / 2;
        arr[i].y = star_y[i];
        arr[i].setspeed = speed;
        arr[i].speed = speed;
        star_now_kind = star_now_kind + 1 > kind_number - 1 ? 0 : star_now_kind + 1;
    }
    return arr;
}
function star_main_fun (star) {
    if (star.length <= 0) {return;}
    if (star[star.length - 1].y > _H) {
        new_star = star[star.length - 1];
        new_star.x = Math.floor(Math.random() * _W);
        if (new_star.inf == main_frame_image_inf.large_star_inf) {
            new_star.y = -500;
        } else {
            new_star.y = -new_star.height;
        }
        star.pop();
        star.unshift(new_star);
    }
}
//mini_star
var mini_star = create_star(1,mini_star_count,4,main_frame_image_inf.mini_star_inf);
//medium_star
var medium_star = create_star(2,medium_star_count,6,main_frame_image_inf.medium_star_inf);
//large_star
var large_star = create_star(1,large_star_count,7,main_frame_image_inf.large_star_inf,true);

//弹出设置窗口
$(".settingBtn").click(function(){
    $('#settingModal').modal('show');
});

//返回浏览器 canvas 是否支持
function canvasSupport() {
    return !!document.createElement('canvas').getContext;
}

// canvas 主函数
function canvasApp(notload) {
    //检查浏览器 canvas 支持
    if (!canvasSupport()) {
        return;
    }

    ///计算每个对象的数据
    //line
    var line = {
        "source" : line_frame_canvas,
        "inf" : line_inf,
        "s_x" : 0,
        "s_y" : 0,
        "s_width" : line_inf.frame_width,
        "s_height" : line_inf.frame_height,
        "x" : _W / 2 - 395,
        "y" : _H - 219 - 5,
        "width" : line_inf.frame_width - 5,
        "height" : line_inf.frame_height + 5,
        "row" : 0,
        "now_frame_number" : 0,
        draw : function (context) {
            if (this.now_frame_number >= this.inf.col_count) {
                this.now_frame_number = 0;
            }
            this.s_x = this.now_frame_number * this.s_width;
            draw(this,context);
            this.now_frame_number ++; 
        }
    }
    var line_b = {};
    $.extend(line_b,line);
    line_b.x = line_b.x - _W;

    //cat_line
    var cat_line = {
        "source" : cat_line_frame_canvas,
        "inf" : cat_line_inf,
        "s_x" : 0,
        "s_y" : 0,
        "s_width" : cat_line_inf.frame_width,
        "s_height" : cat_line_inf.frame_height,
        "x" : _W / 2 - 578,
        "y" : _H - 225,
        "width" : cat_line_inf.frame_width,
        "height" : cat_line_inf.frame_height,
        "row" : 0,
        "now_frame_number" : 0,
        draw : function (context) {
            if (this.now_frame_number >= this.inf.count) {
                this.now_frame_number = 0;
            }
            var x_n = this.now_frame_number % 11;
            var y_n = parseInt(this.now_frame_number / 11);
            this.s_x = x_n * this.s_width;
            this.s_y = y_n * this.s_height;
            draw(this,context);
            this.now_frame_number ++; 
        }
    }
    var cat_line_b = {};
    $.extend(cat_line_b,cat_line);
    cat_line_b.x = cat_line_b.x - _W;

    //彩虹条纹
    rainbow_stripes_class = {
        "create" : function () {
            var rainbow_stripes = {};
            rainbow_stripes.source = main_frame_image_canvas;
            rainbow_stripes.s_x = 0;
            rainbow_stripes.s_y = 0;
            rainbow_stripes.s_width = 0;
            rainbow_stripes.s_height = 0;
            rainbow_stripes.x = 0;
            rainbow_stripes.y = 0;
            rainbow_stripes.width = 0;
            rainbow_stripes.height = 0;
            rainbow_stripes.row = 0;
            rainbow_stripes.draw = function (context) {
                draw(rainbow_stripes,context);
            };
            return rainbow_stripes;
        },
    };
    var rainbow_stripes = [];
    rainbow_stripes.length = 2;
    for (var i = 0; i < rainbow_stripes.length; i++) {
        rainbow_stripes[i] = rainbow_stripes_class.create();
        rainbow_stripes[i].row = main_frame_image_inf.rainbow_stripes_inf[i].row;
        rainbow_stripes[i].s_width = main_frame_image_inf.row_width_height[rainbow_stripes[i].row][0];
        rainbow_stripes[i].s_height = main_frame_image_inf.row_width_height[rainbow_stripes[i].row][1];
        rainbow_stripes[i].s_x = main_frame_image_inf.rainbow_stripes_inf[i].content[0] * rainbow_stripes[i].s_width;
        var s_y_temp = 0;
        for (var j = 0; j < rainbow_stripes[i].row; j++) {
            s_y_temp += main_frame_image_inf.row_width_height[j][1];
        }
        rainbow_stripes[i].s_y = s_y_temp;
        rainbow_stripes[i].width = rainbow_stripes[i].s_width;
        rainbow_stripes[i].height = rainbow_stripes[i].s_height;
    };
    rainbow_stripes[0].x = - 267;
    rainbow_stripes[0].y = - 198;
    rainbow_stripes[1].x = _W / 2 - 1258;
    rainbow_stripes[1].y = _H - 406;

    //云
    cloud_class = {
        "create" : function () {
            var cloud = {};
            cloud.source = main_frame_image_canvas;
            cloud.s_x = 0;
            cloud.s_y = 0;
            cloud.s_width = 0;
            cloud.s_height = 0;
            cloud.x = 0;
            cloud.y = 0;
            cloud.width = 0;
            cloud.height = 0;
            cloud.mouse_response_margin_rect_prop = 1;
            cloud.row = 0;
            cloud.draw = function (context) {
                draw(cloud,context);
            };
            return cloud;
        },
    };
    var cloud = [];
    cloud.length = 5;
    for (var i = 0; i < cloud.length; i++) {
        cloud[i] = cloud_class.create();
        cloud[i].row = main_frame_image_inf.cloud_inf[i].row;
        cloud[i].s_width = main_frame_image_inf.row_width_height[cloud[i].row][0];
        cloud[i].s_height = main_frame_image_inf.row_width_height[cloud[i].row][1];
        cloud[i].s_x = main_frame_image_inf.cloud_inf[i].content[0] * cloud[i].s_width;
        var s_y_temp = 0;
        for (var j = 0; j < cloud[i].row; j++) {
            s_y_temp += main_frame_image_inf.row_width_height[j][1];
        }
        cloud[i].s_y = s_y_temp;
        cloud[i].width = cloud[i].s_width;
        cloud[i].height = cloud[i].s_height;
    };
    cloud[0].x = _W / 2 - 233;
    cloud[0].y = _H - 972;
    cloud[0].mouse_response_margin_rect_prop = 0.45;
    cloud[1].x = _W / 2 - 744;
    cloud[1].y = _H - 1114;
    cloud[1].mouse_response_margin_rect_prop = 0.55;
    cloud[2].x = _W / 2 - (-300);
    cloud[2].y = _H - 1090;
    cloud[2].mouse_response_margin_rect_prop = 0.65;
    cloud[3].x = _W / 2 - (- 516);
    cloud[3].y = _H - 606;
    cloud[3].mouse_response_margin_rect_prop = 0.95;
    cloud[4].x = _W / 2 - 850;
    cloud[4].y = _H - 686;
    cloud[4].mouse_response_margin_rect_prop = 1;

    //人物
    role_class = {
        "create" : function () {
            var role = {};
            role.source = role_frame_image_canvas;
            role.s_x = 0;
            role.s_y = 0;
            role.s_width = role_frame_image_inf.frame_width;
            role.s_height = role_frame_image_inf.frame_height;
            role.x = 0;
            role.y = 0;
            role.width = role_frame_image_inf.frame_width;
            role.height = role_frame_image_inf.frame_height;
            role.time = 0;
            role.interval = 250;
            role.sound = document.createElement("audio");
            role.walk = null;
            role.jump = null;
            role.state = null;
            role.now_frame_number = 0;
            role.row = 0;
            role.make_sound = function () {
                if (role_sound_mute == 1) {return;}
                role.sound.play();
            }
            role.change_state = function () {
                role.now_frame_number = 0;
                role.time = 0;
                role.state = role.state == role.walk ? role.jump : role.walk;
                return role.state;
            }
            role.draw = function (context) {
                if (role.state == role.walk) {
                    role.time += draw_speed;
                    if (role.time != 0 && role.time % role.interval == 0) {
                        role.time = 0;
                        role.s_x = role.state[role.now_frame_number] * role.s_width; 
                        role.now_frame_number = role.now_frame_number + 1 > role.state.length - 1 ? 0 : role.now_frame_number + 1;
                    }
                } else {
                    if (role.now_frame_number == 0) {
                        role.time += draw_speed;
                        if (role.time >= role.interval) {
                            role.time = 0;
                            role.now_frame_number += 1;    
                        } 
                    } else if (role.now_frame_number >= role.state.length - 1) {
                        role.time += draw_speed;
                        if (role.time >= role.interval) {
                            role.now_frame_number = 0;
                            role.change_state();
                        }
                    } else {
                        role.now_frame_number += 1;
                    }
                    role.s_x = role.state[role.now_frame_number] * role.s_width;
                }
                
                draw(role,context);
            };
            return role;
        },
    };
    var role = [];
    role.length = 4;
    for (var i = 0; i < role.length; i++) {
        role[i] = role_class.create();
        role[i].walk = role_frame_image_inf.role_inf[i].walk;
        role[i].jump = role_frame_image_inf.role_inf[i].jump;
        role[i].state = role[i].walk;
        role[i].row = role_frame_image_inf.role_inf[i].row;
        role[i].s_y = role[i].row * role[i].s_height;
    }
    role[0].x = _W / 2 - 684;
    role[0].y = _H - 937;
    role[1].x = _W / 2 - 408;
    role[1].y = _H - 950;
    //role[1].sound.src = "sound/01.ogg"
    role[2].x = _W / 2 - 134;
    role[2].y = _H - 950;
    role[2].sound.src = "sound/02.ogg"
    role[3].x = _W / 2 - (- 162);
    role[3].y = _H - 939;

    
    //地面
    var ground = {
        "source" : ground_image_canvas,
        "s_x" : 0,
        "s_y" : 0,
        "s_width" : ground_image_inf.width,
        "s_height" : ground_image_inf.height,
        "x" : (_W - ground_image_inf.width) / 2,
        "y" : _H - ground_image_inf.height,
        "width" : ground_image_inf.width,
        "height" : ground_image_inf.height,
        "interval" : 0,
        "draw" : function (context) {
            draw(this,context);
        }
    }
    ///-----结束

    document.getElementById('canvasBox').innerHTML = '';
    var myCanvas = document.createElement("canvas");
    myCanvas.setAttribute("width", _W);
    myCanvas.setAttribute("height", _H);
    myCanvas.setAttribute("id", "myCanvas");
    document.getElementById('canvasBox').appendChild(myCanvas);
    var context = myCanvas.getContext('2d');

    //鼠标交互
    function move (tx) {
        var isDown = false;
        var o_x,o_y,mouse_prop_x,mouse_prop_y,o_width,o_height,mX,mY,x,y;
        $(myCanvas).mousedown(function(event) {
            var event = event || window.event;
            o_x = tx.x;
            o_y = tx.y;
            mouse_prop_x = tx.x + tx.width * (1 - tx.mouse_response_margin_rect_prop) / 2;
            mouse_prop_y = tx.y + tx.height * (1 - tx.mouse_response_margin_rect_prop) / 2;
            o_width = tx.width * tx.mouse_response_margin_rect_prop;
            o_height = tx.height * tx.mouse_response_margin_rect_prop;
            context.beginPath(); //关键的一句 （使之前的区域无效）
            context.rect(mouse_prop_x,mouse_prop_y,o_width,o_height);
            context.strokeStyle = "rgba(225,225,225,0)";
            context.stroke();
            if (context.isPointInPath(event.clientX,event.clientY)) {
                isDown = true;
                mX = event.clientX;
                mY = event.clientY;
            }
        });
        $(myCanvas).mousemove(function(event) {
            var event = event || window.event;
            var x = event.clientX;//鼠标滑动时的X轴
            var y = event.clientY;//鼠标滑动时的Y轴
            if(isDown) {
                tx.x = x - mX + o_x;
                tx.y = y - mY + o_y;
            }
        });
        $(myCanvas).mouseup(function() {
            isDown = false;//鼠标拖拽结束
        }); 
    }
    function tx_click(tx) {
        var o_x,o_y,o_width,o_height;
        $(myCanvas).click(function(event) {
            if (tx.state == tx.jump) {
                return;
            }
            var event = event || window.event;
            o_x = tx.x + 215;
            o_y = tx.y + 190;
            o_width = tx.width - 215 * 2;
            o_height = tx.height;
            context.beginPath(); //关键的一句 （使之前的区域无效）
            context.rect(o_x,o_y,o_width,o_height);
            context.strokeStyle = "rgba(225,225,225,0)";
            context.stroke();
            if (context.isPointInPath(event.clientX,event.clientY)) {
                //console.log("click");
                tx.make_sound();
                tx.change_state();
            }
        });
    }
    function pin(tx) {
        var click_time = 0;
        $(myCanvas).click(function(event) {
            var event = event || window.event;
            o_x = tx.x;
            o_y = tx.y;
            mouse_prop_x = tx.x + tx.width * (1 - tx.mouse_response_margin_rect_prop) / 2;
            mouse_prop_y = tx.y + tx.height * (1 - tx.mouse_response_margin_rect_prop) / 2;
            o_width = tx.width * tx.mouse_response_margin_rect_prop;
            o_height = tx.height * tx.mouse_response_margin_rect_prop;
            context.beginPath(); //关键的一句 （使之前的区域无效）
            context.rect(mouse_prop_x,mouse_prop_y,o_width,o_height);
            context.strokeStyle = "rgba(225,225,225,0)";
            context.stroke();
            if (context.isPointInPath(event.clientX,event.clientY)) {
                click_time++;
                if (click_time >= 4) {
                    click_time = 0;
                    tx.speed = tx.speed == 0 ? tx.setspeed : 0 ;
                }        
            }          
        });
    };
    
    for (var i = 0; i < large_star.length; i++) {
        move(large_star[i]);
        pin(large_star[i]);
    }
    for (var i = 0; i < cloud.length; i++) {
        move(cloud[i]);
    }
    for (var i = 0; i < role.length; i++) {
        tx_click(role[i]);
    }
    //定义绘制函数
    function drawSrceen() {
        context.fillStyle = "#ffffff";
        context.fillRect(0,0,_W,_H);
        context.save();

        star_main_fun(mini_star);
        star_main_fun(medium_star);
        star_main_fun(large_star);
        for (var i = 0; i < mini_star.length; i++) {
            mini_star[i].draw(context);
        }
        for (var i = 0; i < rainbow_stripes.length; i++) {
            rainbow_stripes[i].draw(context);
        }
        for (var i = 0; i < medium_star.length; i++) {
            medium_star[i].draw(context);
        }
        for (var i = 0; i < large_star.length; i++) {
            large_star[i].draw(context);
        }
        for (var i = 0; i < cloud.length; i++) {
            cloud[i].draw(context);
        }
        for (var i = 0; i < role.length; i++) {
            role[i].draw(context);
        }
        ground.draw(context);
        line.draw(context);
        cat_line.draw(context);
        context.setTransform(-1,0,0,1,0,0);
        line_b.draw(context);
        cat_line_b.draw(context);

        context.restore();
    }

    //循环绘制
    function gameLoop() {
        window.setTimeout(gameLoop,draw_speed);
        drawSrceen();
    }

    gameLoop();
}

//文档加载时执行
$(document).ready(function() {
    getWindowWH();
    setMainSize();
    canvasApp();
});

//窗口调整大小时执行
$(window).resize(function(event) {
    getWindowWH();
    setMainSize();
    //canvasApp();
});

window.wallpaperPropertyListener = {
    applyUserProperties: function (properties) {
        if (properties.mini_star_count) {
            mini_star_count = properties.mini_star_count.value;
            mini_star = create_star(1,mini_star_count,4,main_frame_image_inf.mini_star_inf);
        }
        if (properties.medium_star_count) {
            medium_star_count = properties.medium_star_count.value;
            medium_star = create_star(2,medium_star_count,6,main_frame_image_inf.medium_star_inf);

        }
        if (properties.large_star_count) {
            large_star_count = properties.large_star_count.value;
            large_star = create_star(1,large_star_count,7,main_frame_image_inf.large_star_inf,true);
        }         
    }
}